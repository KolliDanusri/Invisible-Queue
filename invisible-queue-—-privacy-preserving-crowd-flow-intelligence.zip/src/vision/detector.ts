import { BoundingBox } from '../types/crowd';
import { RawDetection } from './tracker';

export interface FrameAnalysisResult {
  detections: RawDetection[];
  averageLuminance: number; // 0..255
  isLowLight: boolean;
  cameraShakeMetric: number; // 0..100
  isCameraShaking: boolean;
}

export class VideoPersonDetector {
  private prevFrameData: Uint8ClampedArray | null = null;
  private width: number = 320;
  private height: number = 240;
  private offscreenCanvas: HTMLCanvasElement;
  private offscreenCtx: CanvasRenderingContext2D | null;
  private prevGlobalCenterX: number = 0;
  private prevGlobalCenterY: number = 0;

  constructor() {
    this.offscreenCanvas = document.createElement('canvas');
    this.offscreenCanvas.width = this.width;
    this.offscreenCanvas.height = this.height;
    this.offscreenCtx = this.offscreenCanvas.getContext('2d', { willReadFrequently: true });
  }

  public analyzeFrame(
    videoElementOrCanvas: HTMLVideoElement | HTMLCanvasElement,
    scaleX: number = 1,
    scaleY: number = 1
  ): FrameAnalysisResult {
    if (!this.offscreenCtx) {
      return {
        detections: [],
        averageLuminance: 128,
        isLowLight: false,
        cameraShakeMetric: 0,
        isCameraShaking: false,
      };
    }

    // Draw scaled down frame for efficient real-time CV processing
    this.offscreenCtx.drawImage(videoElementOrCanvas, 0, 0, this.width, this.height);
    const frame = this.offscreenCtx.getImageData(0, 0, this.width, this.height);
    const data = frame.data;
    const len = data.length;

    let totalLum = 0;
    let motionPixels = 0;
    let sumMotionX = 0;
    let sumMotionY = 0;

    const threshold = 28; // difference threshold
    const motionGrid: boolean[][] = Array.from({ length: 24 }, () => Array(32).fill(false));
    const cellW = this.width / 32;
    const cellH = this.height / 24;

    if (this.prevFrameData && this.prevFrameData.length === len) {
      for (let i = 0; i < len; i += 4) {
        // Luminance calculation
        const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        const prevLum = 0.299 * this.prevFrameData[i] + 0.587 * this.prevFrameData[i + 1] + 0.114 * this.prevFrameData[i + 2];
        totalLum += lum;

        const diff = Math.abs(lum - prevLum);
        if (diff > threshold) {
          const pixelIdx = i / 4;
          const px = pixelIdx % this.width;
          const py = Math.floor(pixelIdx / this.width);

          motionPixels++;
          sumMotionX += px;
          sumMotionY += py;

          const gx = Math.min(31, Math.floor(px / cellW));
          const gy = Math.min(23, Math.floor(py / cellH));
          motionGrid[gy][gx] = true;
        }
      }
    } else {
      // First frame
      for (let i = 0; i < len; i += 4) {
        totalLum += 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
      }
    }

    const pixelCount = len / 4;
    const avgLuminance = totalLum / pixelCount;
    const isLowLight = avgLuminance < 40;

    // Detect camera shake: check if entire frame shifted uniformly
    let cameraShakeMetric = 0;
    if (motionPixels > 100) {
      const curCenterX = sumMotionX / motionPixels;
      const curCenterY = sumMotionY / motionPixels;
      if (this.prevGlobalCenterX > 0) {
        const drift = Math.hypot(curCenterX - this.prevGlobalCenterX, curCenterY - this.prevGlobalCenterY);
        // If > 25% of the frame is moving synchronously
        const coverageRatio = motionPixels / pixelCount;
        if (coverageRatio > 0.35) {
          cameraShakeMetric = Math.min(100, Math.round(drift * 3 + coverageRatio * 60));
        }
      }
      this.prevGlobalCenterX = curCenterX;
      this.prevGlobalCenterY = curCenterY;
    }

    const isCameraShaking = cameraShakeMetric > 45;

    // Connected components / cluster grid cells into bounding boxes
    const detections: RawDetection[] = [];
    const visited: boolean[][] = Array.from({ length: 24 }, () => Array(32).fill(false));

    for (let gy = 0; gy < 24; gy++) {
      for (let gx = 0; gx < 32; gx++) {
        if (motionGrid[gy][gx] && !visited[gy][gx]) {
          // BFS / Flood fill cluster
          let minX = gx;
          let maxX = gx;
          let minY = gy;
          let maxY = gy;
          let clusterSize = 0;

          const queue: [number, number][] = [[gx, gy]];
          visited[gy][gx] = true;

          while (queue.length > 0) {
            const [cx, cy] = queue.shift()!;
            clusterSize++;
            minX = Math.min(minX, cx);
            maxX = Math.max(maxX, cx);
            minY = Math.min(minY, cy);
            maxY = Math.max(maxY, cy);

            const neighbors: [number, number][] = [
              [cx + 1, cy],
              [cx - 1, cy],
              [cx, cy + 1],
              [cx, cy - 1],
            ];

            for (const [nx, ny] of neighbors) {
              if (
                nx >= 0 &&
                nx < 32 &&
                ny >= 0 &&
                ny < 24 &&
                motionGrid[ny][nx] &&
                !visited[ny][nx]
              ) {
                visited[ny][nx] = true;
                queue.push([nx, ny]);
              }
            }
          }

          // Filter out tiny noise and gigantic whole-frame shifts
          if (clusterSize >= 3 && clusterSize <= 120 && !isCameraShaking) {
            const boxX = minX * cellW * scaleX;
            const boxY = minY * cellH * scaleY;
            const boxW = Math.max(28, (maxX - minX + 1.2) * cellW * scaleX);
            const boxH = Math.max(52, (maxY - minY + 1.6) * cellH * scaleY);

            // Compute confidence based on cluster density and luminance
            let conf = Math.min(0.96, 0.65 + clusterSize * 0.015);
            if (isLowLight) {
              conf = Math.max(0.42, conf * 0.75); // Penalize low-light
            }

            detections.push({
              bbox: {
                x: boxX,
                y: boxY,
                width: boxW,
                height: boxH,
              },
              confidence: Number(conf.toFixed(2)),
            });
          }
        }
      }
    }

    // Save previous frame
    if (!this.prevFrameData) {
      this.prevFrameData = new Uint8ClampedArray(len);
    }
    this.prevFrameData.set(data);

    return {
      detections,
      averageLuminance: Math.round(avgLuminance),
      isLowLight,
      cameraShakeMetric,
      isCameraShaking,
    };
  }

  public reset(): void {
    this.prevFrameData = null;
    this.prevGlobalCenterX = 0;
    this.prevGlobalCenterY = 0;
  }
}
