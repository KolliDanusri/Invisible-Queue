import { AnonymousPersonTrack, BoundingBox } from '../types/crowd';

export interface RawDetection {
  bbox: BoundingBox;
  confidence: number;
}

export class AnonymousTracker {
  private tracks: Map<number, AnonymousPersonTrack> = new Map();
  private nextId: number = 1;
  private maxLostFrames: number = 30; // ~1 second grace period for occlusions
  private iouMatchThreshold: number = 0.25;

  private colorPalette: string[] = [
    '#06b6d4', // cyan-500
    '#3b82f6', // blue-500
    '#10b981', // emerald-500
    '#f59e0b', // amber-500
    '#8b5cf6', // violet-500
    '#ec4899', // pink-500
    '#14b8a6', // teal-500
    '#f97316', // orange-500
  ];

  public reset(): void {
    this.tracks.clear();
    this.nextId = 1;
  }

  // Calculate Intersection over Union between two bounding boxes
  public static calculateIoU(boxA: BoundingBox, boxB: BoundingBox): number {
    const xA = Math.max(boxA.x, boxB.x);
    const yA = Math.max(boxA.y, boxB.y);
    const xB = Math.min(boxA.x + boxA.width, boxB.x + boxB.width);
    const yB = Math.min(boxA.y + boxA.height, boxB.y + boxB.height);

    const interArea = Math.max(0, xB - xA) * Math.max(0, yB - yA);
    if (interArea === 0) return 0;

    const boxAArea = boxA.width * boxA.height;
    const boxBArea = boxB.width * boxB.height;
    const unionArea = boxAArea + boxBArea - interArea;

    return interArea / Math.max(unionArea, 1e-6);
  }

  // Center distance between two bounding boxes (normalized by box dimensions)
  public static centerDistance(boxA: BoundingBox, boxB: BoundingBox): number {
    const cAx = boxA.x + boxA.width / 2;
    const cAy = boxA.y + boxA.height / 2;
    const cBx = boxB.x + boxB.width / 2;
    const cBy = boxB.y + boxB.height / 2;
    return Math.hypot(cAx - cBx, cAy - cBy);
  }

  public update(detections: RawDetection[], timestamp: number, deltaSec: number = 0.033): AnonymousPersonTrack[] {
    const dt = Math.max(0.01, Math.min(0.2, deltaSec));

    // 1. Motion prediction step (Kalman / linear motion model)
    this.tracks.forEach((track) => {
      if (track.state === 'active' || track.state === 'lost') {
        // Project center forward
        track.bbox.x += track.vx * dt;
        track.bbox.y += track.vy * dt;
        track.missedFrames += 1;
        if (track.missedFrames > 3) {
          track.state = 'lost';
          track.confidence = Math.max(0.3, track.confidence * 0.95);
        }
      }
    });

    const activeTrackEntries = Array.from(this.tracks.entries()).filter(
      ([, t]) => t.state === 'active' || t.state === 'lost'
    );

    // 2. Greedy bipartite matching based on IoU + distance
    const matchedTrackIds = new Set<number>();
    const matchedDetIndices = new Set<number>();

    // Sort detections by confidence high to low (ByteTrack concept)
    const sortedDets = detections.map((det, idx) => ({ ...det, originalIndex: idx }));
    sortedDets.sort((a, b) => b.confidence - a.confidence);

    for (const det of sortedDets) {
      let bestTrackId: number | null = null;
      let bestScore = -1;

      for (const [tId, track] of activeTrackEntries) {
        if (matchedTrackIds.has(tId)) continue;

        const iou = AnonymousTracker.calculateIoU(track.bbox, det.bbox);
        const dist = AnonymousTracker.centerDistance(track.bbox, det.bbox);
        const maxDim = Math.max(det.bbox.width, det.bbox.height, 40);

        // Combined association score
        let score = iou;
        if (dist < maxDim * 1.5) {
          // If close enough even if IoU is lower due to sudden jump
          score = Math.max(score, 1 - dist / (maxDim * 2));
        }

        if (score > this.iouMatchThreshold && score > bestScore) {
          bestScore = score;
          bestTrackId = tId;
        }
      }

      if (bestTrackId !== null) {
        matchedTrackIds.add(bestTrackId);
        matchedDetIndices.add(det.originalIndex);

        const track = this.tracks.get(bestTrackId)!;
        const prevCenterX = track.bbox.x + track.bbox.width / 2;
        const prevCenterY = track.bbox.y + track.bbox.height / 2;
        const newCenterX = det.bbox.x + det.bbox.width / 2;
        const newCenterY = det.bbox.y + det.bbox.height / 2;

        // Smooth velocity calculation (exponential moving average)
        const instantVx = (newCenterX - prevCenterX) / dt;
        const instantVy = (newCenterY - prevCenterY) / dt;
        track.vx = track.vx * 0.6 + instantVx * 0.4;
        track.vy = track.vy * 0.6 + instantVy * 0.4;
        track.speed = Math.hypot(track.vx, track.vy);

        // Smooth bounding box update
        track.bbox.x = track.bbox.x * 0.3 + det.bbox.x * 0.7;
        track.bbox.y = track.bbox.y * 0.3 + det.bbox.y * 0.7;
        track.bbox.width = track.bbox.width * 0.3 + det.bbox.width * 0.7;
        track.bbox.height = track.bbox.height * 0.3 + det.bbox.height * 0.7;

        track.confidence = det.confidence * 0.7 + track.confidence * 0.3;
        track.lastSeen = timestamp;
        track.missedFrames = 0;
        track.state = 'active';

        // Add history point
        track.history.push({ x: newCenterX, y: newCenterY, timestamp });
        if (track.history.length > 30) {
          track.history.shift();
        }
      }
    }

    // 3. Initialize new tracks for unmatched confident detections
    for (let i = 0; i < detections.length; i++) {
      if (!matchedDetIndices.has(i) && detections[i].confidence >= 0.5) {
        const det = detections[i];
        const numId = this.nextId++;
        // Format as strictly temporary ID e.g. Person-01
        const formattedId = `Person-${numId.toString().padStart(2, '0')}`;
        const centerX = det.bbox.x + det.bbox.width / 2;
        const centerY = det.bbox.y + det.bbox.height / 2;

        const newTrack: AnonymousPersonTrack = {
          id: formattedId,
          internalId: numId,
          bbox: { ...det.bbox },
          confidence: det.confidence,
          vx: 0,
          vy: 0,
          speed: 0,
          history: [{ x: centerX, y: centerY, timestamp }],
          zoneId: 'unassigned',
          firstSeen: timestamp,
          lastSeen: timestamp,
          state: 'active',
          missedFrames: 0,
          color: this.colorPalette[(numId - 1) % this.colorPalette.length],
          isOverlapping: false,
        };

        this.tracks.set(numId, newTrack);
      }
    }

    // 4. Overlap & Occlusion Detection among active tracks
    const allActive = Array.from(this.tracks.values()).filter((t) => t.state === 'active');
    for (let i = 0; i < allActive.length; i++) {
      allActive[i].isOverlapping = false;
      for (let j = i + 1; j < allActive.length; j++) {
        const iou = AnonymousTracker.calculateIoU(allActive[i].bbox, allActive[j].bbox);
        if (iou > 0.15) {
          allActive[i].isOverlapping = true;
          allActive[j].isOverlapping = true;
          // Temporarily penalize tracking confidence due to overlap
          allActive[i].confidence = Math.max(0.4, allActive[i].confidence * 0.98);
          allActive[j].confidence = Math.max(0.4, allActive[j].confidence * 0.98);
        }
      }
    }

    // 5. Expire tracks that stayed lost past grace period (Zero permanent identity storage)
    for (const [id, track] of this.tracks.entries()) {
      if (track.missedFrames > this.maxLostFrames) {
        track.state = 'terminated';
        this.tracks.delete(id);
      }
    }

    return Array.from(this.tracks.values()).filter(
      (t) => t.state === 'active' || (t.state === 'lost' && t.missedFrames <= 5)
    );
  }

  public getActiveCount(): number {
    return Array.from(this.tracks.values()).filter((t) => t.state === 'active').length;
  }
}
