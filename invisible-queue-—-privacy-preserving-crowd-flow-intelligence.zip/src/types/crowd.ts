export type CongestionState = 'NORMAL' | 'INCREASING' | 'HIGH-RISK CONGESTION';

export type PredictionLevel = 'NORMAL' | 'INCREASING' | 'HIGH-RISK';

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface TrackPoint {
  x: number;
  y: number;
  timestamp: number;
}

export interface AnonymousPersonTrack {
  id: string; // e.g. "Person-01" (strictly temporary)
  internalId: number;
  bbox: BoundingBox;
  confidence: number;
  vx: number; // velocity x (px/s)
  vy: number; // velocity y (px/s)
  speed: number; // magnitude (px/s)
  history: TrackPoint[];
  zoneId: string;
  firstSeen: number;
  lastSeen: number;
  state: 'active' | 'lost' | 'occluded' | 'terminated';
  missedFrames: number;
  color: string;
  isOverlapping?: boolean;
}

export interface ZoneDefinition {
  id: string;
  name: string;
  code: string;
  color: string;
  polygon: { x: number; y: number }[]; // normalized 0..1 coordinates
  capacity: number; // max comfortable person capacity
  isRestricted?: boolean;
  isEntranceClosed?: boolean;
  isAlternateOpen?: boolean;
}

export interface ZoneMetrics {
  zoneId: string;
  zoneName: string;
  currentCount: number;
  density: number; // percentage of comfortable capacity (0..100%+)
  densityPeoplePerM2: number; // calibrated est. people/m²
  entryRate: number; // people / min
  exitRate: number; // people / min
  avgDwellTime: number; // seconds
  avgSpeed: number; // px/s or m/s
  dominantDirection: { angleDeg: number; vx: number; vy: number; label: string };
  inflowOutflowBalance: number; // net change (entry - exit)
  flowConflictScore: number; // 0..1 (degree of opposing vectors)
  congestionRisk: CongestionState;
  reasons: string[];
}

export interface FlowVector {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  speed: number;
  angleDeg: number;
  trackId: string;
}

export interface CongestionSignalEvidence {
  metric: string;
  value: string;
  status: 'normal' | 'warning' | 'critical';
  impact: string;
}

export interface CongestionAssessment {
  overallState: CongestionState;
  score: number; // 0..100
  dominantZoneId: string;
  evidence: CongestionSignalEvidence[];
  reasons: string[];
}

export interface PredictionResult {
  level: PredictionLevel;
  confidence: number; // 0..100%
  timeHorizonSec: number; // e.g. 60 or 180 seconds
  projectedCountInHorizon: number;
  isLowConfidence: boolean;
  lowConfidenceReason?: string;
  trendVelocity: number; // rate of change in density/min
  contributingFactors: string[];
}

export interface AnomalyEvent {
  id: string;
  timestamp: string;
  zoneId: string;
  zoneName: string;
  pattern: 'sudden_movement' | 'density_surge' | 'abnormal_turn' | 'unexpected_stop' | 'inflow_burst' | 'flow_conflict';
  patternLabel: string;
  description: string;
  confidence: number; // 0..100%
  supportingMeasurements: { [key: string]: string | number };
}

export interface RecommendationItem {
  id: string;
  timestamp: string;
  zoneId: string;
  zoneName: string;
  level: 'info' | 'advisory' | 'urgent';
  title: string;
  actionText: string;
  reasoning: string;
  disclaimer: 'AI-generated suggestion';
}

export interface EventLogEntry {
  id: string;
  timestamp: string;
  timeSec: number;
  zone: string;
  event: string;
  category: 'congestion' | 'anomaly' | 'system' | 'privacy' | 'simulation';
  confidence: number;
  recommendation?: string;
  details?: string;
}

export type ScenarioType = 
  | 'normal_flow'
  | 'gradual_congestion'
  | 'high_congestion'
  | 'sudden_crowd_movement'
  | 'overlapping_people'
  | 'low_light';

export interface EnvironmentPreset {
  id: string;
  name: string;
  description: string;
  normalSpeed: number;
  maxDensityCapacity: number;
  dwellThresholdSec: number;
  conflictSensitivity: number;
}

export interface PrivacyConfig {
  blurLevel: 'none' | 'face_only' | 'full_silhouette' | 'abstract_skeleton';
  hideRawVideo: boolean;
  anonymousBoundingBoxesOnly: boolean;
  zeroRawStorageVerified: boolean;
  showConfidenceMetrics: boolean;
  maskProtectedAreas: boolean;
}

export interface SystemHealthMetrics {
  fps: number;
  avgFps: number;
  latencyMs: number;
  luminanceLevel: number; // 0..255
  isLowLight: boolean;
  isCameraShaking: boolean;
  shakeMetric: number;
  overlappingRatio: number; // 0..1
  overallConfidence: number; // 0..100
  confidenceWarnings: string[];
}

export interface SimulationParameters {
  spawnRate: number; // agents/sec
  targetSpeed: number; // px/sec
  agentCount: number;
  entranceClosed: boolean;
  alternatePathOpen: boolean;
  zoneBRestricted: boolean;
  corridorCapacity: number; // 5..50
  bottleneckWidth: number; // px
}
