import { EnvironmentPreset } from '../types/crowd';

export const ENVIRONMENT_PRESETS: EnvironmentPreset[] = [
  {
    id: 'railway_station',
    name: 'Railway Station Concourse',
    description: 'High commuter velocity, strict bottleneck tolerance, high transit turnover.',
    normalSpeed: 42,
    maxDensityCapacity: 28,
    dwellThresholdSec: 15,
    conflictSensitivity: 0.7,
  },
  {
    id: 'shopping_mall',
    name: 'Shopping Mall Atrium',
    description: 'Leisurely pedestrian pace, acceptable dwelling, multi-directional browsing.',
    normalSpeed: 24,
    maxDensityCapacity: 35,
    dwellThresholdSec: 45,
    conflictSensitivity: 0.4,
  },
  {
    id: 'college_corridor',
    name: 'University Campus Hallway',
    description: 'Periodic heavy surge between lecture hours, bidirectional wave traffic.',
    normalSpeed: 38,
    maxDensityCapacity: 22,
    dwellThresholdSec: 12,
    conflictSensitivity: 0.65,
  },
  {
    id: 'stadium_egress',
    name: 'Sports Stadium Turnstiles',
    description: 'High-density mass egress, unidirectional flow priority, critical bottleneck monitoring.',
    normalSpeed: 30,
    maxDensityCapacity: 45,
    dwellThresholdSec: 20,
    conflictSensitivity: 0.85,
  },
];
