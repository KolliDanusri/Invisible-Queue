import { CongestionAssessment, ZoneMetrics } from '../types/crowd';
import { RecommendationItem } from '../types/crowd';

export class RecommendationEngine {
  private lastRecommendations: RecommendationItem[] = [];
  private lastGeneratedTime: number = 0;

  public evaluate(
    congestion: CongestionAssessment,
    zones: ZoneMetrics[],
    currentTime: number
  ): RecommendationItem[] {
    // Generate fresh recommendations when state changes or at least every 6s
    const needsRefresh =
      this.lastRecommendations.length === 0 ||
      currentTime - this.lastGeneratedTime > 6000;

    if (!needsRefresh) {
      return this.lastRecommendations;
    }

    const items: RecommendationItem[] = [];
    const timeStr = new Date(currentTime).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });

    // Defensive fallback in case zones is empty or dominant zone not found
    const defaultZone = {
      zoneId: congestion.dominantZoneId || 'zone-a',
      zoneName: 'Zone A — Main Entrance',
      density: 25,
      avgDwellTime: 12,
      avgSpeed: 35,
      entryRate: 10,
      exitRate: 10,
      flowConflictScore: 0.1,
    };

    const worstZone =
      zones.find((z) => z && z.zoneId === congestion.dominantZoneId) ||
      zones[0] ||
      defaultZone;

    if (congestion.overallState === 'HIGH-RISK CONGESTION') {
      items.push({
        id: `rec-${currentTime}-1`,
        timestamp: timeStr,
        zoneId: worstZone.zoneId,
        zoneName: worstZone.zoneName,
        level: 'urgent',
        title: `Throttle Upstream Inflow into ${worstZone.zoneName}`,
        actionText: `Temporarily restrict or meter entry rate by 40% at upstream turnstiles to relieve persistent compression.`,
        reasoning: `Density reached ${worstZone.density}% with prolonged dwell time (${worstZone.avgDwellTime}s) and near-zero transit speed (${worstZone.avgSpeed} px/s).`,
        disclaimer: 'AI-generated suggestion',
      });

      items.push({
        id: `rec-${currentTime}-2`,
        timestamp: timeStr,
        zoneId: 'zone-d',
        zoneName: 'Zone D — Egress Corridor',
        level: 'urgent',
        title: 'Activate Alternate Bypass Corridor (Pathway D)',
        actionText: 'Deploy operational signage to divert 50% of oncoming foot-traffic to the secondary egress pathway.',
        reasoning: 'Reduces counter-flow collision index and rebalances inflow/outflow delta.',
        disclaimer: 'AI-generated suggestion',
      });
    } else if (congestion.overallState === 'INCREASING') {
      items.push({
        id: `rec-${currentTime}-3`,
        timestamp: timeStr,
        zoneId: worstZone.zoneId,
        zoneName: worstZone.zoneName,
        level: 'advisory',
        title: `Proactive Monitoring at ${worstZone.zoneName}`,
        actionText: 'Keep floor marshals informed and verify all automated egress doors remain completely unobstructed.',
        reasoning: `Inflow (+${worstZone.entryRate}/m) is outstripping outflow (-${worstZone.exitRate}/m) with rising density (${worstZone.density}%).`,
        disclaimer: 'AI-generated suggestion',
      });

      if (worstZone.flowConflictScore > 0.3) {
        items.push({
          id: `rec-${currentTime}-4`,
          timestamp: timeStr,
          zoneId: worstZone.zoneId,
          zoneName: worstZone.zoneName,
          level: 'advisory',
          title: 'Establish Single-Direction Lane Channeling',
          actionText: 'Utilize stanchions or floor directional lighting to separate northbound and southbound movement streams.',
          reasoning: `Counter-flow friction index is currently elevated at ${worstZone.flowConflictScore}.`,
          disclaimer: 'AI-generated suggestion',
        });
      }
    } else {
      // Normal state
      items.push({
        id: `rec-${currentTime}-5`,
        timestamp: timeStr,
        zoneId: worstZone.zoneId || 'all',
        zoneName: worstZone.zoneName || 'Facility Wide',
        level: 'info',
        title: 'Nominal Crowd Flow Baseline Maintained',
        actionText: 'Continue standard automated computer-vision surveillance. No manual queue intervention required.',
        reasoning: 'All monitored corridors operate below 55% density capacity with fluid movement velocity.',
        disclaimer: 'AI-generated suggestion',
      });
    }


    this.lastRecommendations = items;
    this.lastGeneratedTime = currentTime;
    return items;
  }
}
