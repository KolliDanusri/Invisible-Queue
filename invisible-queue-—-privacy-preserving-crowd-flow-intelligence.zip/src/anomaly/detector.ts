import { AnomalyEvent, AnonymousPersonTrack, ZoneMetrics } from '../types/crowd';

export class AnomalyDetector {
  private recentEvents: AnomalyEvent[] = [];
  private lastAlertTime: number = 0;
  private prevZoneSpeeds: Map<string, number> = new Map();
  private prevZoneCounts: Map<string, number> = new Map();
  private prevZoneAngles: Map<string, number> = new Map();

  public evaluate(
    zones: ZoneMetrics[],
    tracks: AnonymousPersonTrack[],
    currentTime: number
  ): AnomalyEvent | null {
    // Throttle duplicate anomaly alerts within 4 seconds
    const throttleMs = 4000;
    const canEmit = currentTime - this.lastAlertTime > throttleMs;

    let detectedEvent: AnomalyEvent | null = null;

    for (const zone of zones) {
      if (!zone || !zone.zoneId) continue;
      const zoneTracks = tracks.filter((t) => t.zoneId === zone.zoneId);
      const prevSpeed = this.prevZoneSpeeds.get(zone.zoneId) ?? zone.avgSpeed;
      const prevCount = this.prevZoneCounts.get(zone.zoneId) ?? zone.currentCount;
      const prevAngle = this.prevZoneAngles.get(zone.zoneId) ?? zone.dominantDirection.angleDeg;

      // 1. Sudden crowd movement (velocity surge > 2.5x with >= 3 people)
      if (zoneTracks.length >= 3 && zone.avgSpeed > 45 && prevSpeed < 18) {
        if (canEmit) {
          detectedEvent = {
            id: `anom-${currentTime}`,
            timestamp: new Date(currentTime).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            zoneId: zone.zoneId,
            zoneName: zone.zoneName,
            pattern: 'sudden_movement',
            patternLabel: 'Sudden Crowd Acceleration',
            description: 'Unusual movement pattern detected: Collective acceleration spike across active tracks.',
            confidence: 84,
            supportingMeasurements: {
              'Previous Velocity': `${prevSpeed.toFixed(1)} px/s`,
              'Current Velocity': `${zone.avgSpeed.toFixed(1)} px/s`,
              'Velocity Delta': `+${(zone.avgSpeed - prevSpeed).toFixed(1)} px/s`,
              'Agents Involved': zoneTracks.length,
            },
          };
        }
      }

      // 2. Abnormal direction change (e.g. collective reversal > 120 degrees within 1-2 sec)
      if (!detectedEvent && zoneTracks.length >= 3 && zone.avgSpeed > 15) {
        const angleDiff = Math.abs(zone.dominantDirection.angleDeg - prevAngle);
        const angularDisplacement = Math.min(angleDiff, 360 - angleDiff);
        if (angularDisplacement > 110) {
          if (canEmit) {
            detectedEvent = {
              id: `anom-${currentTime}`,
              timestamp: new Date(currentTime).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
              zoneId: zone.zoneId,
              zoneName: zone.zoneName,
              pattern: 'abnormal_turn',
              patternLabel: 'Collective Trajectory Reversal',
              description: 'Unusual movement pattern detected: Sharp angular divergence in dominant crowd heading.',
              confidence: 81,
              supportingMeasurements: {
                'Displacement Angle': `${angularDisplacement}°`,
                'Previous Direction': `${Math.round(prevAngle)}°`,
                'New Direction': `${zone.dominantDirection.angleDeg}° (${zone.dominantDirection.label})`,
                'Tracks Aligned': zoneTracks.length,
              },
            };
          }
        }
      }

      // 3. Sudden density increase (count jumped by >= 5 in 1s)
      if (!detectedEvent && (zone.currentCount - prevCount) >= 6) {
        if (canEmit) {
          detectedEvent = {
            id: `anom-${currentTime}`,
            timestamp: new Date(currentTime).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            zoneId: zone.zoneId,
            zoneName: zone.zoneName,
            pattern: 'density_surge',
            patternLabel: 'Abrupt Inflow Influx',
            description: 'Unusual movement pattern detected: Rapid surge in localized occupant count.',
            confidence: 88,
            supportingMeasurements: {
              'Baseline Occupancy': prevCount,
              'Surge Occupancy': zone.currentCount,
              'Delta': `+${zone.currentCount - prevCount} occupants`,
              'Rate of Influx': `${zone.entryRate}/min`,
            },
          };
        }
      }

      // 4. Unexpected collective stopping (speed dropped from > 25 to < 5 with density > 50%)
      if (!detectedEvent && prevSpeed > 24 && zone.avgSpeed < 5 && zone.currentCount >= 4) {
        if (canEmit) {
          detectedEvent = {
            id: `anom-${currentTime}`,
            timestamp: new Date(currentTime).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            zoneId: zone.zoneId,
            zoneName: zone.zoneName,
            pattern: 'unexpected_stop',
            patternLabel: 'Abrupt Queue Deceleration',
            description: 'Unusual movement pattern detected: Unexpected stagnation in previously moving corridor.',
            confidence: 79,
            supportingMeasurements: {
              'Initial Speed': `${prevSpeed.toFixed(1)} px/s`,
              'Current Speed': `${zone.avgSpeed.toFixed(1)} px/s`,
              'Deceleration Delta': `-${(prevSpeed - zone.avgSpeed).toFixed(1)} px/s`,
              'Corridor Density': `${zone.density}%`,
            },
          };
        }
      }

      // Update state for next evaluation
      this.prevZoneSpeeds.set(zone.zoneId, zone.avgSpeed);
      this.prevZoneCounts.set(zone.zoneId, zone.currentCount);
      if (zone.avgSpeed > 10) {
        this.prevZoneAngles.set(zone.zoneId, zone.dominantDirection.angleDeg);
      }
    }

    if (detectedEvent) {
      this.lastAlertTime = currentTime;
      this.recentEvents.unshift(detectedEvent);
      if (this.recentEvents.length > 20) {
        this.recentEvents.pop();
      }
      return detectedEvent;
    }

    return null;
  }

  public getRecentEvents(): AnomalyEvent[] {
    return this.recentEvents;
  }

  public clear(): void {
    this.recentEvents = [];
    this.lastAlertTime = 0;
  }
}
