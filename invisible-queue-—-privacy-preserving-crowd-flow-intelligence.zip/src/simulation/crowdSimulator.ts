import { BoundingBox, ScenarioType, SimulationParameters } from '../types/crowd';
import { RawDetection } from '../vision/tracker';

export interface SimulatedAgent {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  targetX: number;
  targetY: number;
  baseSpeed: number;
  width: number;
  height: number;
  color: string;
  hasReversed?: boolean;
}

export class CrowdSimulationEngine {
  private width: number = 800;
  private height: number = 500;
  private agents: SimulatedAgent[] = [];
  private nextAgentId: number = 1;
  private scenario: ScenarioType = 'normal_flow';
  private scenarioStartTime: number = 0;
  private params: SimulationParameters = {
    spawnRate: 1.5,
    targetSpeed: 45,
    agentCount: 16,
    entranceClosed: false,
    alternatePathOpen: false,
    zoneBRestricted: false,
    corridorCapacity: 20,
    bottleneckWidth: 120,
  };

  private spawnAccumulator: number = 0;

  constructor(width: number = 800, height: number = 500) {
    this.width = width;
    this.height = height;
    this.loadScenario('normal_flow');
  }

  public setDimensions(width: number, height: number): void {
    this.width = width;
    this.height = height;
  }

  public getParameters(): SimulationParameters {
    return { ...this.params };
  }

  public updateParameters(newParams: Partial<SimulationParameters>): void {
    this.params = { ...this.params, ...newParams };
  }

  public getScenario(): ScenarioType {
    return this.scenario;
  }

  public loadScenario(scenario: ScenarioType): void {
    this.scenario = scenario;
    this.scenarioStartTime = Date.now();
    this.agents = [];
    this.nextAgentId = 1;
    this.spawnAccumulator = 0;

    switch (scenario) {
      case 'normal_flow':
        this.params.agentCount = 14;
        this.params.targetSpeed = 48;
        this.params.spawnRate = 1.2;
        this.params.entranceClosed = false;
        this.params.alternatePathOpen = false;
        this.params.zoneBRestricted = false;
        this.seedInitialAgents(14, 'west_to_east');
        break;

      case 'gradual_congestion':
        this.params.agentCount = 18;
        this.params.targetSpeed = 38;
        this.params.spawnRate = 3.5; // High influx
        this.params.entranceClosed = false;
        this.params.alternatePathOpen = false;
        this.seedInitialAgents(16, 'concourse_influx');
        break;

      case 'high_congestion':
        this.params.agentCount = 38;
        this.params.targetSpeed = 12; // Gridlock crawl
        this.params.spawnRate = 4.0;
        this.params.entranceClosed = false;
        this.params.alternatePathOpen = false;
        this.params.bottleneckWidth = 70; // Narrow bottleneck
        this.seedInitialAgents(32, 'chokepoint');
        break;

      case 'sudden_crowd_movement':
        this.params.agentCount = 20;
        this.params.targetSpeed = 55;
        this.params.spawnRate = 1.0;
        this.seedInitialAgents(20, 'group_march');
        break;

      case 'overlapping_people':
        this.params.agentCount = 24;
        this.params.targetSpeed = 40;
        this.params.spawnRate = 2.0;
        this.seedInitialAgents(24, 'criss_cross'); // Direct crossing lines causing heavy overlap
        break;

      case 'low_light':
        this.params.agentCount = 12;
        this.params.targetSpeed = 35;
        this.params.spawnRate = 1.0;
        this.seedInitialAgents(12, 'west_to_east');
        break;
    }
  }

  private seedInitialAgents(count: number, pattern: string) {
    for (let i = 0; i < count; i++) {
      let x = 60 + Math.random() * (this.width - 120);
      let y = 60 + Math.random() * (this.height - 120);
      let tx = this.width - 60;
      let ty = y;

      if (pattern === 'west_to_east') {
        x = 40 + (i / count) * (this.width * 0.8);
        y = 100 + (i % 4) * 80 + (Math.random() * 20 - 10);
        tx = this.width + 40;
        ty = y;
      } else if (pattern === 'chokepoint') {
        // Packed near center bottleneck
        x = this.width * 0.42 + Math.random() * (this.width * 0.22);
        y = this.height * 0.2 + Math.random() * (this.height * 0.6);
        tx = this.width * 0.85;
        ty = this.height * 0.5;
      } else if (pattern === 'criss_cross') {
        // Half moving East, half moving West, overlapping directly
        const isEast = i % 2 === 0;
        y = 180 + (i % 3) * 50;
        if (isEast) {
          x = 60 + (i * 25);
          tx = this.width - 50;
        } else {
          x = this.width - 60 - (i * 25);
          tx = 50;
        }
        ty = y;
      } else if (pattern === 'group_march') {
        x = 100 + (i % 5) * 45;
        y = 120 + Math.floor(i / 5) * 55;
        tx = this.width - 80;
        ty = y;
      }

      this.agents.push({
        id: this.nextAgentId++,
        x,
        y,
        vx: 0,
        vy: 0,
        targetX: tx,
        targetY: ty,
        baseSpeed: this.params.targetSpeed * (0.85 + Math.random() * 0.3),
        width: 32,
        height: 64,
        color: '#64748b',
        hasReversed: false,
      });
    }
  }

  public update(deltaSec: number): void {
    const elapsedSec = (Date.now() - this.scenarioStartTime) / 1000;
    const dt = Math.max(0.01, Math.min(0.1, deltaSec));

    // Scripted Scenario Events
    if (this.scenario === 'sudden_crowd_movement') {
      // At t=6s, entire group suddenly reverses direction
      const cycleTime = elapsedSec % 12;
      const shouldReverse = cycleTime > 6;
      for (const agent of this.agents) {
        if (shouldReverse && !agent.hasReversed) {
          agent.targetX = 60;
          agent.targetY = agent.y + (Math.random() * 40 - 20);
          agent.baseSpeed = 75; // sudden burst
          agent.hasReversed = true;
        } else if (!shouldReverse && agent.hasReversed) {
          agent.targetX = this.width - 60;
          agent.baseSpeed = 48;
          agent.hasReversed = false;
        }
      }
    } else if (this.scenario === 'gradual_congestion') {
      // Density steadily escalates over 30s
      this.params.targetSpeed = Math.max(14, 45 - elapsedSec * 1.0);
    }

    // Dynamic Spawning
    if (!this.params.entranceClosed) {
      this.spawnAccumulator += this.params.spawnRate * dt;
      if (this.spawnAccumulator >= 1 && this.agents.length < this.params.agentCount + 15) {
        this.spawnAccumulator -= 1;
        const startY = 120 + Math.random() * (this.height - 240);
        let targetX = this.width - 40;
        let targetY = startY;

        // What-if simulator route diversion
        if (this.params.alternatePathOpen) {
          // Route 50% through alternate corridor (lower path)
          if (Math.random() > 0.5) {
            targetY = this.height - 80;
          }
        }

        this.agents.push({
          id: this.nextAgentId++,
          x: 20,
          y: startY,
          vx: 30,
          vy: 0,
          targetX,
          targetY,
          baseSpeed: this.params.targetSpeed * (0.85 + Math.random() * 0.3),
          width: 32,
          height: 64,
          color: '#64748b',
        });
      }
    }

    // Social force model / agent physics
    for (let i = 0; i < this.agents.length; i++) {
      const a = this.agents[i];

      // 1. Goal seeking force
      const dx = a.targetX - a.x;
      const dy = a.targetY - a.y;
      const dist = Math.hypot(dx, dy);

      let desiredVx = 0;
      let desiredVy = 0;
      if (dist > 15) {
        desiredVx = (dx / dist) * a.baseSpeed;
        desiredVy = (dy / dist) * a.baseSpeed;
      }

      // 2. Inter-agent repulsive force
      let repulseX = 0;
      let repulseY = 0;
      for (let j = 0; j < this.agents.length; j++) {
        if (i === j) continue;
        const b = this.agents[j];
        const sepX = a.x - b.x;
        const sepY = a.y - b.y;
        const sepDist = Math.hypot(sepX, sepY);
        const minDist = 38; // personal space

        if (sepDist > 0 && sepDist < minDist) {
          const force = (minDist - sepDist) / minDist;
          repulseX += (sepX / sepDist) * force * 60;
          repulseY += (sepY / sepDist) * force * 60;
        }
      }

      // 3. Bottleneck / Zone restriction avoidance
      if (this.params.zoneBRestricted) {
        // Push away from Zone B (top right)
        if (a.x > this.width * 0.5 && a.y < this.height * 0.5) {
          repulseY += 80; // push down towards lower corridor
        }
      }

      // Blend forces
      a.vx = a.vx * 0.7 + (desiredVx + repulseX) * 0.3;
      a.vy = a.vy * 0.7 + (desiredVy + repulseY) * 0.3;

      // Limit speed
      const curSpeed = Math.hypot(a.vx, a.vy);
      const maxSpd = Math.max(a.baseSpeed * 1.4, 20);
      if (curSpeed > maxSpd) {
        a.vx = (a.vx / curSpeed) * maxSpd;
        a.vy = (a.vy / curSpeed) * maxSpd;
      }

      // Update position
      a.x += a.vx * dt;
      a.y += a.vy * dt;

      // Boundary clamp
      a.x = Math.max(30, Math.min(this.width - 30, a.x));
      a.y = Math.max(40, Math.min(this.height - 50, a.y));

      // Reset agent if reached target
      if (dist < 25) {
        if (this.scenario === 'normal_flow' || this.scenario === 'gradual_congestion' || this.scenario === 'high_congestion') {
          a.x = 25;
          a.y = 100 + Math.random() * (this.height - 200);
          a.targetX = this.width - 35;
          a.targetY = a.y;
        }
      }
    }
  }

  // Generate realistic synthetic camera detections
  public getDetections(): { detections: RawDetection[]; isLowLight: boolean; isCameraShaking: boolean } {
    const isLowLight = this.scenario === 'low_light';
    const isCameraShaking = false;

    const detections: RawDetection[] = this.agents.map((agent) => {
      // Base detection confidence
      let confidence = 0.88 + (Math.sin(agent.id) * 0.08);

      // Low light penalty (honest evaluation)
      if (isLowLight) {
        confidence = Math.max(0.38, confidence * 0.65);
      }

      // Add slight bounding box jitter like real CV
      const jitterX = (Math.random() - 0.5) * 3;
      const jitterY = (Math.random() - 0.5) * 3;

      return {
        bbox: {
          x: Math.round(agent.x - agent.width / 2 + jitterX),
          y: Math.round(agent.y - agent.height / 2 + jitterY),
          width: Math.round(agent.width),
          height: Math.round(agent.height),
        },
        confidence: Number(confidence.toFixed(2)),
      };
    });

    // In low light, 20% of low-confidence detections might drop out naturally
    const filtered = isLowLight
      ? detections.filter((d) => d.confidence > 0.45 || Math.random() > 0.25)
      : detections;

    return {
      detections: filtered,
      isLowLight,
      isCameraShaking,
    };
  }

  // Render synthetic visual scene onto background canvas
  public renderScene(ctx: CanvasRenderingContext2D, privacyBlur: boolean = false): void {
    ctx.save();

    // Background concourse floor
    const isLow = this.scenario === 'low_light';
    ctx.fillStyle = isLow ? '#080c14' : '#0f172a';
    ctx.fillRect(0, 0, this.width, this.height);

    // Floor architectural grid lines
    ctx.strokeStyle = isLow ? 'rgba(255, 255, 255, 0.02)' : 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let x = 0; x < this.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.height);
      ctx.stroke();
    }
    for (let y = 0; y < this.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(this.width, y);
      ctx.stroke();
    }

    // Walls / Corridor structures
    ctx.fillStyle = 'rgba(30, 41, 59, 0.7)';
    ctx.fillRect(0, 0, this.width, 16); // North wall
    ctx.fillRect(0, this.height - 16, this.width, 16); // South wall

    // Turnstile / Entrance gate marks
    ctx.fillStyle = this.params.entranceClosed ? 'rgba(239, 68, 68, 0.4)' : 'rgba(6, 182, 212, 0.2)';
    ctx.fillRect(5, 50, 18, this.height - 100);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.fillText(this.params.entranceClosed ? 'GATE CLOSED' : 'INFLOW GATE', 28, 70);

    // If alternate path open, render green pathway guide
    if (this.params.alternatePathOpen) {
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.35)';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 6]);
      ctx.strokeRect(this.width * 0.1, this.height - 90, this.width * 0.8, 60);
      ctx.setLineDash([]);
      ctx.fillStyle = '#10b981';
      ctx.fillText('ALTERNATE BYPASS CORRIDOR ACTIVE', this.width * 0.35, this.height - 55);
    }

    // Render human figures (stylized anonymous silhouettes)
    for (const agent of this.agents) {
      ctx.save();
      ctx.translate(agent.x, agent.y);

      // Floor shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, agent.height / 2 - 4, 14, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      if (privacyBlur) {
        // Anonymized blurred silhouette
        ctx.filter = 'blur(4px)';
      }

      // Torso / clothes silhouette (strictly non-identifiable anonymous geometry)
      const bodyColor = isLow ? '#334155' : '#475569';
      ctx.fillStyle = bodyColor;

      // Head
      ctx.beginPath();
      ctx.arc(0, -agent.height / 2 + 10, 7, 0, Math.PI * 2);
      ctx.fill();

      // Torso
      ctx.beginPath();
      ctx.roundRect(-10, -agent.height / 2 + 18, 20, 26, 4);
      ctx.fill();

      // Legs
      ctx.fillRect(-8, -agent.height / 2 + 44, 6, 18);
      ctx.fillRect(2, -agent.height / 2 + 44, 6, 18);

      ctx.restore();
    }

    ctx.restore();
  }
}
