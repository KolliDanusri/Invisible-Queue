import { AnonymousPersonTrack } from '../types/crowd';

export class HeatmapRenderer {
  private offscreenCanvas: HTMLCanvasElement;
  private offscreenCtx: CanvasRenderingContext2D | null;
  private gradientPalette: ImageData | null = null;

  constructor(width: number = 400, height: number = 250) {
    this.offscreenCanvas = document.createElement('canvas');
    this.offscreenCanvas.width = width;
    this.offscreenCanvas.height = height;
    this.offscreenCtx = this.offscreenCanvas.getContext('2d', { willReadFrequently: true });
    this.initGradient();
  }

  public resize(width: number, height: number): void {
    this.offscreenCanvas.width = width;
    this.offscreenCanvas.height = height;
    this.initGradient();
  }

  private initGradient(): void {
    const gradCanvas = document.createElement('canvas');
    gradCanvas.width = 256;
    gradCanvas.height = 1;
    const gradCtx = gradCanvas.getContext('2d');
    if (!gradCtx) return;

    const grad = gradCtx.createLinearGradient(0, 0, 256, 0);
    grad.addColorStop(0.0, 'rgba(6, 182, 212, 0)'); // transparent cyan
    grad.addColorStop(0.2, 'rgba(6, 182, 212, 0.4)'); // cool cyan
    grad.addColorStop(0.45, 'rgba(59, 130, 246, 0.65)'); // blue
    grad.addColorStop(0.7, 'rgba(245, 158, 11, 0.85)'); // amber
    grad.addColorStop(0.9, 'rgba(239, 68, 68, 0.95)'); // crimson
    grad.addColorStop(1.0, 'rgba(225, 29, 72, 1.0)'); // hot red

    gradCtx.fillStyle = grad;
    gradCtx.fillRect(0, 0, 256, 1);
    this.gradientPalette = gradCtx.getImageData(0, 0, 256, 1);
  }

  public render(
    ctx: CanvasRenderingContext2D,
    tracks: AnonymousPersonTrack[],
    destWidth: number,
    destHeight: number,
    opacity: number = 0.55
  ): void {
    if (!this.offscreenCtx || !this.gradientPalette) return;

    const w = this.offscreenCanvas.width;
    const h = this.offscreenCanvas.height;
    const scaleX = w / destWidth;
    const scaleY = h / destHeight;

    // Clear alpha canvas
    this.offscreenCtx.clearRect(0, 0, w, h);

    // 1. Splat radial gradient discs onto alpha canvas
    const radius = 38;
    for (const track of tracks) {
      const cx = (track.bbox.x + track.bbox.width / 2) * scaleX;
      const cy = (track.bbox.y + track.bbox.height / 2) * scaleY;

      const radGrad = this.offscreenCtx.createRadialGradient(cx, cy, 2, cx, cy, radius);
      radGrad.addColorStop(0, 'rgba(0, 0, 0, 0.45)');
      radGrad.addColorStop(0.5, 'rgba(0, 0, 0, 0.22)');
      radGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

      this.offscreenCtx.fillStyle = radGrad;
      this.offscreenCtx.beginPath();
      this.offscreenCtx.arc(cx, cy, radius, 0, Math.PI * 2);
      this.offscreenCtx.fill();
    }

    // 2. Colorize alpha channel using gradient palette
    const imgData = this.offscreenCtx.getImageData(0, 0, w, h);
    const pixels = imgData.data;
    const gradData = this.gradientPalette.data;

    for (let i = 0; i < pixels.length; i += 4) {
      const alpha = pixels[i + 3]; // 0..255
      if (alpha > 0) {
        const palIdx = alpha * 4;
        pixels[i] = gradData[palIdx]; // R
        pixels[i + 1] = gradData[palIdx + 1]; // G
        pixels[i + 2] = gradData[palIdx + 2]; // B
        pixels[i + 3] = Math.round(alpha * opacity); // dynamic alpha blend
      }
    }

    this.offscreenCtx.putImageData(imgData, 0, 0);

    // 3. Draw colorized heatmap back onto target canvas
    ctx.save();
    ctx.drawImage(this.offscreenCanvas, 0, 0, destWidth, destHeight);
    ctx.restore();
  }
}
