import { AnonymousPersonTrack, FlowVector } from '../types/crowd';

export class FlowAnalyzer {
  public static extractFlowVectors(tracks: AnonymousPersonTrack[]): FlowVector[] {
    const vectors: FlowVector[] = [];

    for (const track of tracks) {
      if (track.speed > 8 && track.history.length >= 2) {
        const current = track.history[track.history.length - 1];
        // Calculate angle
        const angleRad = Math.atan2(track.vy, track.vx);
        let angleDeg = Math.round((angleRad * 180) / Math.PI);
        if (angleDeg < 0) angleDeg += 360;

        // Vector length scaled to speed
        const arrowLength = Math.min(40, Math.max(16, track.speed * 0.4));
        const endX = current.x + (track.vx / (track.speed || 1)) * arrowLength;
        const endY = current.y + (track.vy / (track.speed || 1)) * arrowLength;

        vectors.push({
          startX: current.x,
          startY: current.y,
          endX,
          endY,
          speed: track.speed,
          angleDeg,
          trackId: track.id,
        });
      }
    }

    return vectors;
  }

  // Calculate global flow conflict index (0..1)
  public static computeGlobalConflictIndex(tracks: AnonymousPersonTrack[]): number {
    const moving = tracks.filter((t) => t.speed > 10);
    if (moving.length < 2) return 0;

    let oppositeCount = 0;
    let comparisons = 0;

    for (let i = 0; i < moving.length; i++) {
      for (let j = i + 1; j < moving.length; j++) {
        const dot = (moving[i].vx * moving[j].vx + moving[i].vy * moving[j].vy) /
          (moving[i].speed * moving[j].speed);
        if (dot < -0.3) {
          oppositeCount++;
        }
        comparisons++;
      }
    }

    if (comparisons === 0) return 0;
    return Number(Math.min(1, (oppositeCount / comparisons) * 2.5).toFixed(2));
  }
}
