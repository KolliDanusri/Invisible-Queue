import { CongestionAssessment, CongestionSignalEvidence, CongestionState, ZoneMetrics } from '../types/crowd';

export class CongestionEngine {
  private prevDensities: Map<string, number> = new Map();

  public evaluate(zones: ZoneMetrics[], globalConflictIndex: number): CongestionAssessment {
    let highestZoneScore = 0;
    let worstZone = zones[0] || null;
    const globalEvidence: CongestionSignalEvidence[] = [];
    const reasons: string[] = [];

    for (const zone of zones) {
      let zoneScore = 0;
      const zoneReasons: string[] = [];

      // 1. Density signal (weight ~25%)
      const density = zone.density;
      if (density >= 85) {
        zoneScore += 30;
        zoneReasons.push(`High density capacity (${density}%)`);
      } else if (density >= 60) {
        zoneScore += 18;
        zoneReasons.push(`Elevated density (${density}%)`);
      }

      // 2. Movement speed signal (weight ~25%)
      // If people are packing and speed drops to near stationary
      const speed = zone.avgSpeed;
      if (zone.currentCount >= 4) {
        if (speed < 12) {
          zoneScore += 25;
          zoneReasons.push(`Severe speed deceleration (${speed} px/s)`);
        } else if (speed < 25) {
          zoneScore += 14;
          zoneReasons.push(`Reduced movement velocity (${speed} px/s)`);
        }
      }

      // 3. Direction conflicts (weight ~20%)
      if (zone.flowConflictScore > 0.45) {
        zoneScore += 20;
        zoneReasons.push(`Heavy counter-flow conflict (index ${zone.flowConflictScore})`);
      } else if (zone.flowConflictScore > 0.25) {
        zoneScore += 10;
        zoneReasons.push(`Moderate flow intersection conflict (${zone.flowConflictScore})`);
      }

      // 4. Inflow vs Outflow imbalance (weight ~15%)
      if (zone.inflowOutflowBalance > 8) {
        zoneScore += 15;
        zoneReasons.push(`Net accumulation: Inflow (+${zone.entryRate}/m) >> Outflow (-${zone.exitRate}/m)`);
      } else if (zone.inflowOutflowBalance > 3) {
        zoneScore += 8;
        zoneReasons.push(`Positive accumulation delta (+${zone.inflowOutflowBalance}/min)`);
      }

      // 5. Dwell time signal (weight ~15%)
      if (zone.avgDwellTime > 25 && zone.currentCount >= 4) {
        zoneScore += 15;
        zoneReasons.push(`Prolonged stagnation: Avg dwell time ${zone.avgDwellTime}s`);
      } else if (zone.avgDwellTime > 15 && zone.currentCount >= 3) {
        zoneScore += 8;
        zoneReasons.push(`Elevated dwell time (${zone.avgDwellTime}s)`);
      }

      // Check density growth rate
      const prevDensity = this.prevDensities.get(zone.zoneId) ?? density;
      const growthRate = density - prevDensity;
      if (growthRate >= 15) {
        zoneScore += 10;
        zoneReasons.push(`Rapid density surge (+${growthRate}% delta)`);
      }
      this.prevDensities.set(zone.zoneId, density);

      // Determine state for this zone
      let zoneState: CongestionState = 'NORMAL';
      if (zoneScore >= 60) {
        zoneState = 'HIGH-RISK CONGESTION';
      } else if (zoneScore >= 32) {
        zoneState = 'INCREASING';
      }
      zone.congestionRisk = zoneState;
      zone.reasons = zoneReasons;

      if (zoneScore > highestZoneScore) {
        highestZoneScore = zoneScore;
        worstZone = zone;
      }
    }

    // Incorporate global flow conflict if high
    if (globalConflictIndex > 0.5) {
      highestZoneScore = Math.min(100, highestZoneScore + 10);
    }

    // Overall state determination
    let overallState: CongestionState = 'NORMAL';
    if (highestZoneScore >= 60) {
      overallState = 'HIGH-RISK CONGESTION';
    } else if (highestZoneScore >= 32) {
      overallState = 'INCREASING';
    }

    // Build evidence table
    if (worstZone) {
      globalEvidence.push({
        metric: 'Worst Zone Density',
        value: `${worstZone.density}% of capacity (${worstZone.currentCount} people)`,
        status: worstZone.density > 80 ? 'critical' : worstZone.density > 50 ? 'warning' : 'normal',
        impact: worstZone.density > 80 ? 'Severe compression' : 'Normal buffer',
      });
      globalEvidence.push({
        metric: 'Average Movement Speed',
        value: `${worstZone.avgSpeed} px/s`,
        status: worstZone.avgSpeed < 15 && worstZone.currentCount > 3 ? 'critical' : worstZone.avgSpeed < 25 ? 'warning' : 'normal',
        impact: worstZone.avgSpeed < 15 ? 'Flow stagnation' : 'Fluid motion',
      });
      globalEvidence.push({
        metric: 'Flow Conflict Index',
        value: `${worstZone.flowConflictScore} (Global: ${globalConflictIndex})`,
        status: worstZone.flowConflictScore > 0.4 ? 'critical' : worstZone.flowConflictScore > 0.2 ? 'warning' : 'normal',
        impact: worstZone.flowConflictScore > 0.4 ? 'Opposing stream friction' : 'Aligned trajectories',
      });
      globalEvidence.push({
        metric: 'Inflow / Outflow Balance',
        value: `+${worstZone.entryRate} in / -${worstZone.exitRate} out (Δ ${worstZone.inflowOutflowBalance}/m)`,
        status: worstZone.inflowOutflowBalance > 8 ? 'critical' : worstZone.inflowOutflowBalance > 3 ? 'warning' : 'normal',
        impact: worstZone.inflowOutflowBalance > 5 ? 'Active queue buildup' : 'Steady equilibrium',
      });
      globalEvidence.push({
        metric: 'Mean Dwell Time',
        value: `${worstZone.avgDwellTime} seconds`,
        status: worstZone.avgDwellTime > 25 ? 'critical' : worstZone.avgDwellTime > 15 ? 'warning' : 'normal',
        impact: worstZone.avgDwellTime > 25 ? 'Severe exit blockage' : 'Transit zone clear',
      });

      reasons.push(...worstZone.reasons);
    }

    if (reasons.length === 0) {
      reasons.push('Density within comfortable baseline limits');
      reasons.push('Continuous forward movement without persistent queues');
      reasons.push('Inflow and outflow rates well balanced');
    }

    return {
      overallState,
      score: Math.min(100, Math.round(highestZoneScore)),
      dominantZoneId: worstZone?.zoneId || 'zone-a',
      evidence: globalEvidence,
      reasons,
    };
  }
}
