import { AnonymousPersonTrack, ZoneDefinition, ZoneMetrics } from '../types/crowd';

export const DEFAULT_ZONES: ZoneDefinition[] = [
  {
    id: 'zone-a',
    name: 'Zone A — Main Entrance',
    code: 'ZONE-A',
    color: '#06b6d4', // cyan
    polygon: [
      { x: 0.05, y: 0.05 },
      { x: 0.48, y: 0.05 },
      { x: 0.48, y: 0.48 },
      { x: 0.05, y: 0.48 },
    ],
    capacity: 22,
    isEntranceClosed: false,
    isAlternateOpen: false,
  },
  {
    id: 'zone-b',
    name: 'Zone B — Concourse Bottleneck',
    code: 'ZONE-B',
    color: '#f59e0b', // amber
    polygon: [
      { x: 0.52, y: 0.05 },
      { x: 0.95, y: 0.05 },
      { x: 0.95, y: 0.48 },
      { x: 0.52, y: 0.48 },
    ],
    capacity: 18,
    isRestricted: false,
  },
  {
    id: 'zone-c',
    name: 'Zone C — Transit Gate',
    code: 'ZONE-C',
    color: '#3b82f6', // blue
    polygon: [
      { x: 0.05, y: 0.52 },
      { x: 0.48, y: 0.52 },
      { x: 0.48, y: 0.95 },
      { x: 0.05, y: 0.95 },
    ],
    capacity: 20,
  },
  {
    id: 'zone-d',
    name: 'Zone D — Egress Corridor',
    code: 'ZONE-D',
    color: '#10b981', // emerald
    polygon: [
      { x: 0.52, y: 0.52 },
      { x: 0.95, y: 0.52 },
      { x: 0.95, y: 0.95 },
      { x: 0.52, y: 0.95 },
    ],
    capacity: 25,
  },
];

export class ZoneManager {
  private zones: ZoneDefinition[];
  // Track history of entry / exit per zone: { zoneId: { entries: timestamp[], exits: timestamp[], dwellTimes: number[] } }
  private zoneEvents: Map<string, { entries: number[]; exits: number[]; dwellTimes: number[] }> = new Map();
  // Map of trackId -> { zoneId, enteredAt }
  private trackZoneHistory: Map<string, { zoneId: string; enteredAt: number }> = new Map();

  constructor(initialZones?: ZoneDefinition[]) {
    this.zones = initialZones ? [...initialZones] : JSON.parse(JSON.stringify(DEFAULT_ZONES));
    this.initEvents();
  }

  private initEvents() {
    this.zones.forEach((z) => {
      if (!this.zoneEvents.has(z.id)) {
        this.zoneEvents.set(z.id, { entries: [], exits: [], dwellTimes: [] });
      }
    });
  }

  public getZones(): ZoneDefinition[] {
    return this.zones;
  }

  public updateZone(updatedZone: ZoneDefinition): void {
    const idx = this.zones.findIndex((z) => z.id === updatedZone.id);
    if (idx !== -1) {
      this.zones[idx] = { ...updatedZone };
    }
  }

  public setCapacity(zoneId: string, capacity: number): void {
    const z = this.zones.find((item) => item.id === zoneId);
    if (z) z.capacity = Math.max(5, capacity);
  }

  public toggleEntranceClosed(zoneId: string, closed: boolean): void {
    const z = this.zones.find((item) => item.id === zoneId);
    if (z) z.isEntranceClosed = closed;
  }

  public toggleZoneRestricted(zoneId: string, restricted: boolean): void {
    const z = this.zones.find((item) => item.id === zoneId);
    if (z) z.isRestricted = restricted;
  }

  public toggleAlternateOpen(zoneId: string, open: boolean): void {
    const z = this.zones.find((item) => item.id === zoneId);
    if (z) z.isAlternateOpen = open;
  }

  // Point in polygon test (Ray casting algorithm)
  public static isPointInPolygon(
    normX: number,
    normY: number,
    polygon: { x: number; y: number }[]
  ): boolean {
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i].x;
      const yi = polygon[i].y;
      const xj = polygon[j].x;
      const yj = polygon[j].y;

      const intersect =
        yi > normY !== yj > normY &&
        normX < ((xj - xi) * (normY - yi)) / (yj - yi + 1e-9) + xi;
      if (intersect) inside = !inside;
    }
    return inside;
  }

  public assignTracksToZones(
    tracks: AnonymousPersonTrack[],
    sceneWidth: number,
    sceneHeight: number,
    currentTime: number
  ): void {
    const activeTrackIds = new Set<string>();

    for (const track of tracks) {
      activeTrackIds.add(track.id);
      const centerX = (track.bbox.x + track.bbox.width / 2) / sceneWidth;
      const centerY = (track.bbox.y + track.bbox.height / 2) / sceneHeight;

      let assignedZoneId = 'outside';
      for (const zone of this.zones) {
        if (ZoneManager.isPointInPolygon(centerX, centerY, zone.polygon)) {
          assignedZoneId = zone.id;
          break;
        }
      }

      const prev = this.trackZoneHistory.get(track.id);
      if (!prev) {
        // First time observed
        this.trackZoneHistory.set(track.id, { zoneId: assignedZoneId, enteredAt: currentTime });
        if (assignedZoneId !== 'outside') {
          const events = this.zoneEvents.get(assignedZoneId);
          events?.entries.push(currentTime);
        }
      } else if (prev.zoneId !== assignedZoneId) {
        // Transitioned between zones
        if (prev.zoneId !== 'outside') {
          const prevEvents = this.zoneEvents.get(prev.zoneId);
          if (prevEvents) {
            prevEvents.exits.push(currentTime);
            const dwell = Math.max(1, (currentTime - prev.enteredAt) / 1000);
            prevEvents.dwellTimes.push(dwell);
            if (prevEvents.dwellTimes.length > 50) prevEvents.dwellTimes.shift();
          }
        }
        if (assignedZoneId !== 'outside') {
          const newEvents = this.zoneEvents.get(assignedZoneId);
          newEvents?.entries.push(currentTime);
        }
        this.trackZoneHistory.set(track.id, { zoneId: assignedZoneId, enteredAt: currentTime });
      }

      track.zoneId = assignedZoneId;
    }

    // Clean up tracks no longer active
    for (const [trackId, data] of this.trackZoneHistory.entries()) {
      if (!activeTrackIds.has(trackId)) {
        if (data.zoneId !== 'outside') {
          const events = this.zoneEvents.get(data.zoneId);
          if (events) {
            events.exits.push(currentTime);
            const dwell = Math.max(1, (currentTime - data.enteredAt) / 1000);
            events.dwellTimes.push(dwell);
            if (events.dwellTimes.length > 50) events.dwellTimes.shift();
          }
        }
        this.trackZoneHistory.delete(trackId);
      }
    }
  }

  public computeMetrics(
    tracks: AnonymousPersonTrack[],
    currentTime: number
  ): ZoneMetrics[] {
    const oneMinuteAgo = currentTime - 60000;

    return this.zones.map((zone) => {
      const zoneTracks = tracks.filter((t) => t.zoneId === zone.id);
      const count = zoneTracks.length;
      const densityPct = Math.round((count / Math.max(1, zone.capacity)) * 100);
      const densityPeoplePerM2 = Number((count / (zone.capacity * 0.4)).toFixed(2));

      // Event rates
      const events = this.zoneEvents.get(zone.id) || { entries: [], exits: [], dwellTimes: [] };
      // Prune events older than 60s
      events.entries = events.entries.filter((t) => t >= oneMinuteAgo);
      events.exits = events.exits.filter((t) => t >= oneMinuteAgo);

      const entryRate = events.entries.length; // per min
      const exitRate = events.exits.length; // per min
      const inflowOutflowBalance = entryRate - exitRate;

      // Average dwell time
      let avgDwellTime = 12.0; // fallback default
      if (events.dwellTimes.length > 0) {
        const sum = events.dwellTimes.reduce((acc, v) => acc + v, 0);
        avgDwellTime = Number((sum / events.dwellTimes.length).toFixed(1));
      } else if (zoneTracks.length > 0) {
        const activeDwells = zoneTracks.map((t) => {
          const rec = this.trackZoneHistory.get(t.id);
          return rec ? Math.max(1, (currentTime - rec.enteredAt) / 1000) : 5;
        });
        avgDwellTime = Number((activeDwells.reduce((a, b) => a + b, 0) / activeDwells.length).toFixed(1));
      }

      // Average speed & Dominant direction
      let sumVx = 0;
      let sumVy = 0;
      let sumSpeed = 0;
      let flowConflictScore = 0;

      if (zoneTracks.length > 0) {
        zoneTracks.forEach((t) => {
          sumVx += t.vx;
          sumVy += t.vy;
          sumSpeed += t.speed;
        });

        // Compute direction conflicts (dot products between pairs)
        if (zoneTracks.length >= 2) {
          let conflictSum = 0;
          let pairCount = 0;
          for (let i = 0; i < zoneTracks.length; i++) {
            for (let j = i + 1; j < zoneTracks.length; j++) {
              const ti = zoneTracks[i];
              const tj = zoneTracks[j];
              const magI = Math.hypot(ti.vx, ti.vy);
              const magJ = Math.hypot(tj.vx, tj.vy);
              if (magI > 5 && magJ > 5) {
                const dot = (ti.vx * tj.vx + ti.vy * tj.vy) / (magI * magJ);
                // If dot < -0.2 (moving in opposing directions)
                if (dot < -0.2) {
                  conflictSum += Math.abs(dot);
                }
                pairCount++;
              }
            }
          }
          if (pairCount > 0) {
            flowConflictScore = Number(Math.min(1, conflictSum / pairCount).toFixed(2));
          }
        }
      }

      const avgVx = zoneTracks.length > 0 ? sumVx / zoneTracks.length : 0;
      const avgVy = zoneTracks.length > 0 ? sumVy / zoneTracks.length : 0;
      const avgSpeed = zoneTracks.length > 0 ? Number((sumSpeed / zoneTracks.length).toFixed(1)) : 0;

      const angleRad = Math.atan2(avgVy, avgVx);
      let angleDeg = Math.round((angleRad * 180) / Math.PI);
      if (angleDeg < 0) angleDeg += 360;

      let dirLabel = 'Static';
      if (avgSpeed > 8) {
        if (angleDeg >= 315 || angleDeg < 45) dirLabel = 'East →';
        else if (angleDeg >= 45 && angleDeg < 135) dirLabel = 'South ↓';
        else if (angleDeg >= 135 && angleDeg < 225) dirLabel = 'West ←';
        else dirLabel = 'North ↑';
      }

      return {
        zoneId: zone.id,
        zoneName: zone.name,
        currentCount: count,
        density: densityPct,
        densityPeoplePerM2,
        entryRate,
        exitRate,
        avgDwellTime,
        avgSpeed,
        dominantDirection: {
          angleDeg,
          vx: avgVx,
          vy: avgVy,
          label: dirLabel,
        },
        inflowOutflowBalance,
        flowConflictScore,
        congestionRisk: 'NORMAL', // will be evaluated by congestion engine
        reasons: [],
      };
    });
  }
}
