import React, { useState } from 'react';
import {
  Presentation,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  X,
  Copy,
  Sparkles,
  Shield,
  Video,
  Eye,
  Sliders,
  AlertTriangle,
  Flame,
  Activity,
  Layers,
  Award,
} from 'lucide-react';
import { ScenarioType } from '../types/crowd';

interface LinkedInPresentationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectScenario: (scenario: ScenarioType) => void;
  onSwitchTab: (tab: string) => void;
}

export const LinkedInPresentationModal: React.FC<LinkedInPresentationModalProps> = ({
  isOpen,
  onClose,
  onSelectScenario,
  onSwitchTab,
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [copiedPost, setCopiedPost] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);

  if (!isOpen) return null;

  const steps = [
    {
      step: 1,
      title: '1. Baseline Nominal Crowd Flow',
      actionPrompt: 'Observe smooth, distributed pedestrian movement through concourse corridors.',
      explanation:
        'The vision pipeline processes raw video without face detection, creating ephemeral single-session bounding boxes. System state is flagged as NORMAL with balanced inflow/outflow.',
      scenario: 'normal_flow' as ScenarioType,
      targetTab: 'monitor',
    },
    {
      step: 2,
      title: '2. Anonymous Multi-Person Tracking',
      actionPrompt: 'Inspect temporary identifiers (Person-01, Person-02) and tracking confidence.',
      explanation:
        'Uses ByteTrack-inspired IoU association and linear velocity Kalman prediction. IDs expire the moment an individual departs the frame, ensuring zero permanent identity indexing.',
      scenario: 'normal_flow' as ScenarioType,
      targetTab: 'monitor',
    },
    {
      step: 3,
      title: '3. Real-Time Gaussian Heatmap',
      actionPrompt: 'Toggle the dynamic density heat surface to observe localized spatial concentration.',
      explanation:
        'Offscreen alpha-blended Gaussian splatting updates continuously. Clear disclaimer: density concentration visualizes density, not standalone danger.',
      scenario: 'normal_flow' as ScenarioType,
      targetTab: 'monitor',
    },
    {
      step: 4,
      title: '4. Increasing Density & Inflow Buildup',
      actionPrompt: 'Observe crowd density escalating in Concourse Zone B.',
      explanation:
        'The multi-signal engine flags state as INCREASING based on 5 combined signals: density growth rate (+35%), net accumulation (inflow > outflow), and transit speed decay.',
      scenario: 'gradual_congestion' as ScenarioType,
      targetTab: 'analytics',
    },
    {
      step: 5,
      title: '5. Early Congestion Time-Series Prediction',
      actionPrompt: 'Review the 90-second forward lookahead forecast and trend velocity.',
      explanation:
        'Mathematical regression projects upcoming occupant counts. Transparently presents confidence percentage and influencing factors instead of claiming black-box certainty.',
      scenario: 'gradual_congestion' as ScenarioType,
      targetTab: 'risk',
    },
    {
      step: 6,
      title: '6. Unusual Movement Pattern Detection',
      actionPrompt: 'Observe detection of rapid direction reversal or collective velocity burst.',
      explanation:
        'Flags sudden angular divergence and velocity variance spikes. Uses honest phrasing: "Unusual movement pattern detected" rather than assuming hazard.',
      scenario: 'sudden_crowd_movement' as ScenarioType,
      targetTab: 'anomalies',
    },
    {
      step: 7,
      title: '7. Operational AI Recommendations',
      actionPrompt: 'Inspect autonomous operational suggestions for facility marshals.',
      explanation:
        'Generates tactical diversion actions (e.g. meter turnstiles, channel flow, open egress). Strictly labeled with "AI-generated suggestion" disclaimer.',
      scenario: 'high_congestion' as ScenarioType,
      targetTab: 'anomalies',
    },
    {
      step: 8,
      title: '8. Interactive What-If Scenario Sandbox',
      actionPrompt: 'Simulate turnstile closure or activating an alternate bypass corridor.',
      explanation:
        'Allows venue managers to test interventions before physical deployment. Labeled prominently: "SIMULATION — NOT A GUARANTEED REAL-WORLD PREDICTION".',
      scenario: 'normal_flow' as ScenarioType,
      targetTab: 'simulator',
    },
    {
      step: 9,
      title: '9. Real-World Robustness: Overlapping Occlusions',
      actionPrompt: 'Examine high-density crisscrossing crowd with bounding box intersections.',
      explanation:
        'When agents overlap, tracking memory preserves track persistence across momentary occlusions while marking overlap flags.',
      scenario: 'overlapping_people' as ScenarioType,
      targetTab: 'monitor',
    },
    {
      step: 10,
      title: '10. Failure-Safe Behavior & Confidence Degradation',
      actionPrompt: 'Simulate low-light environment and observe system safety guardrails.',
      explanation:
        'The system refuses to invent false certainty: luminance drops below threshold, triggering: "LOW CONFIDENCE: Improve lighting or reposition camera".',
      scenario: 'low_light' as ScenarioType,
      targetTab: 'monitor',
    },
  ];

  const handleStepSelect = (idx: number) => {
    setCurrentStep(idx);
    if (idx < steps.length) {
      const s = steps[idx];
      onSelectScenario(s.scenario);
      onSwitchTab(s.targetTab);
    }
  };

  const linkedInPostText = `🚨 Privacy-Preserving Computer Vision for Public Spaces: INVISIBLE QUEUE

Traditional crowd management surveillance systems rely on facial recognition and persistent biometric tracking—creating immense privacy and regulatory risks under GDPR and CCPA.

I built INVISIBLE QUEUE: a real-time computer vision system that detects, tracks, understands, and predicts pedestrian congestion WITHOUT identifying people.

⚙️ Core Technical Pipeline:
1️⃣ Anonymous Multi-Person Tracking: ByteTrack-inspired association with temporary tokens (Person-01, Person-02). Ephemeral IDs expire upon frame departure. Zero facial recognition or permanent biometric storage.
2️⃣ Dynamic Zone Intelligence: Ray-casting polygon zones measuring localized density, dwell times, inflow/outflow deltas, and counter-flow conflict indices.
3️⃣ Multi-Signal Congestion Engine: Rejects the flaw of using density alone; combines velocity decay, direction divergence, and queue accretion.
4️⃣ Early Time-Series Prediction: Forward 90-second horizon regression estimating risk trends with calibrated confidence intervals.
5️⃣ Anomaly Detection: Identifies unusual collective velocity spikes and trajectory reversals.
6️⃣ Interactive What-If Simulator: Allows venue operators to simulate turnstile closures and bypass corridor diversions.
7️⃣ Robustness & Failure-Safety: Gracefully flags low-confidence states during severe occlusions or poor illumination instead of hallucinating certainties.

Built with React, TypeScript, Canvas Vision processing, and Tailwind CSS.

#ComputerVision #AI #PrivacyByDesign #CrowdManagement #MachineLearning #SmartCities #OpenSource`;

  const pitchScriptText = `[0:00 - 0:10] "This is Invisible Queue—a computer vision system that predicts crowd congestion without recognizing a single face or storing any biometric data."
[0:10 - 0:25] "Here, people move through dynamic concourse zones. Notice the bounding boxes: each receives a strictly temporary token like Person-01. When someone departs, their track is permanently purged from memory."
[0:25 - 0:40] "Rather than using density alone, our engine combines movement speed, counter-flow collision angles, and net inflow accumulation. It forecasts congestion 90 seconds ahead and generates operational suggestions for venue staff."
[0:40 - 0:55] "We also built an interactive What-If Simulator to model corridor closures in real time, and explicit failure-safe alerts when lighting or occlusions reduce confidence."
[0:55 - 1:00] "Invisible Queue: Actionable crowd intelligence with uncompromising privacy by design."`;

  const copyToClipboard = (text: string, type: 'post' | 'script') => {
    navigator.clipboard.writeText(text);
    if (type === 'post') {
      setCopiedPost(true);
      setTimeout(() => setCopiedPost(false), 2500);
    } else {
      setCopiedScript(true);
      setTimeout(() => setCopiedScript(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Presentation className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white tracking-wide">
              LinkedIn & Academic Presentation Studio
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {currentStep < steps.length ? (
            /* 10-Step Interactive Guide */
            <div className="space-y-5">
              {/* Step Progress Dots */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-xs font-mono font-bold text-cyan-400">
                  STEP {currentStep + 1} OF {steps.length}
                </span>
                <div className="flex items-center gap-1.5">
                  {steps.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleStepSelect(idx)}
                      className={`h-2 rounded-full transition-all ${
                        currentStep === idx
                          ? 'w-6 bg-cyan-400'
                          : idx < currentStep
                          ? 'w-2 bg-emerald-500'
                          : 'w-2 bg-slate-700'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Active Step Showcase Card */}
              <div className="p-5 rounded-xl bg-slate-950/80 border border-cyan-500/30 space-y-3">
                <h3 className="text-lg font-bold text-white font-mono">
                  {steps[currentStep].title}
                </h3>
                <div className="p-3 rounded-lg bg-cyan-950/30 border border-cyan-500/20 text-xs text-cyan-200 font-medium">
                  <strong>Demo Action: </strong>
                  {steps[currentStep].actionPrompt}
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {steps[currentStep].explanation}
                </p>
              </div>

              {/* Navigation buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  disabled={currentStep === 0}
                  onClick={() => handleStepSelect(currentStep - 1)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 disabled:opacity-40 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous Step
                </button>

                <button
                  onClick={() => handleStepSelect(currentStep + 1)}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-md transition-colors"
                >
                  {currentStep === steps.length - 1 ? 'View Presentation Capstone' : 'Next Step'}
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            /* Final Capstone Screen matching Section 32 */
            <div className="space-y-6 text-center py-4">
              <div className="inline-flex p-3 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mb-2">
                <Award className="w-8 h-8" />
              </div>

              <div>
                <h1 className="text-2xl font-extrabold text-white tracking-wider uppercase font-mono">
                  Privacy-Preserving Crowd Flow Intelligence
                </h1>
                <p className="text-xs text-slate-400 mt-1 max-w-lg mx-auto">
                  End-to-End Production Prototype for Autonomous Venue & Transit Flow Monitoring
                </p>
              </div>

              {/* Core Pillars Grid */}
              <div className="grid grid-cols-2 md:grid-cols-6 gap-3 pt-3">
                {[
                  { label: 'AI', sub: 'Autonomous Insights' },
                  { label: 'Computer Vision', sub: 'Spatial Blob Tracking' },
                  { label: 'Anonymous Tracking', sub: 'Zero Biometrics' },
                  { label: 'Prediction', sub: '90s Time-Series' },
                  { label: 'Simulation', sub: 'What-If Sandbox' },
                  { label: 'Privacy', sub: 'GDPR / CCPA Non-PII' },
                ].map((col, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex flex-col justify-center"
                  >
                    <span className="text-sm font-bold font-mono text-cyan-400 block">
                      {col.label}
                    </span>
                    <span className="text-[10px] text-slate-400 mt-0.5">{col.sub}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 flex justify-center gap-3">
                <button
                  onClick={() => setCurrentStep(0)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 transition-colors"
                >
                  Replay 10-Step Tour
                </button>
              </div>
            </div>
          )}

          {/* Collapsible Copyable LinkedIn Post & Pitch Script Section */}
          <div className="border-t border-slate-800 pt-5 space-y-4">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              Ready-to-Publish LinkedIn Post & Video Pitch Script:
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* LinkedIn Post */}
              <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-200">
                      LinkedIn Post Text (Markdown formatted)
                    </span>
                    <button
                      onClick={() => copyToClipboard(linkedInPostText, 'post')}
                      className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-cyan-300 transition-colors"
                    >
                      <Copy className="w-3 h-3" />
                      {copiedPost ? 'Copied!' : 'Copy Post'}
                    </button>
                  </div>
                  <pre className="text-[11px] text-slate-400 font-mono whitespace-pre-wrap max-h-36 overflow-y-auto leading-relaxed p-2 rounded bg-slate-900 border border-slate-800">
                    {linkedInPostText}
                  </pre>
                </div>
              </div>

              {/* 30-60s Video Script */}
              <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-200">
                      30–60 Second Video Pitch Script
                    </span>
                    <button
                      onClick={() => copyToClipboard(pitchScriptText, 'script')}
                      className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-cyan-300 transition-colors"
                    >
                      <Copy className="w-3 h-3" />
                      {copiedScript ? 'Copied!' : 'Copy Script'}
                    </button>
                  </div>
                  <pre className="text-[11px] text-slate-400 font-mono whitespace-pre-wrap max-h-36 overflow-y-auto leading-relaxed p-2 rounded bg-slate-900 border border-slate-800">
                    {pitchScriptText}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
