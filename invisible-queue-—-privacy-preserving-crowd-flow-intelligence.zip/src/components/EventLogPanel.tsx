import React, { useState } from 'react';
import { EventLogEntry } from '../types/crowd';
import {
  ListFilter,
  Download,
  Trash2,
  Calendar,
  AlertTriangle,
  Activity,
  Shield,
  Sparkles,
} from 'lucide-react';

interface EventLogPanelProps {
  logs: EventLogEntry[];
  onClearLogs: () => void;
}

export const EventLogPanel: React.FC<EventLogPanelProps> = ({ logs, onClearLogs }) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const filteredLogs = logs.filter((log) => {
    if (filterCategory === 'all') return true;
    return log.category === filterCategory;
  });

  const exportCSV = () => {
    const headers = ['Timestamp', 'Zone', 'Event', 'Category', 'Confidence', 'Recommendation'];
    const rows = logs.map((l) => [
      `"${l.timestamp}"`,
      `"${l.zone}"`,
      `"${l.event.replace(/"/g, '""')}"`,
      `"${l.category}"`,
      `"${l.confidence}%"`,
      `"${(l.recommendation || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `crowd_intelligence_audit_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm flex flex-col gap-3">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <ListFilter className="w-4 h-4 text-cyan-400" />
          <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
            Operational Event Audit Log
          </h3>
          <span className="text-xs text-slate-500">· {filteredLogs.length} events</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Category Filter */}
          <div className="flex items-center gap-1 p-0.5 rounded bg-slate-950 border border-slate-800 text-[11px]">
            {['all', 'congestion', 'anomaly', 'simulation'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-2 py-0.5 rounded capitalize font-medium transition-colors ${
                  filterCategory === cat
                    ? 'bg-slate-800 text-cyan-300'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition-colors"
            title="Export audit log to CSV"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>

          <button
            onClick={onClearLogs}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700 transition-colors"
            title="Clear event log"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto max-h-72 overflow-y-auto">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-slate-950/60 text-slate-500 uppercase text-[10px] tracking-wider border-b border-slate-800 sticky top-0">
            <tr>
              <th className="py-2 px-3">Timestamp</th>
              <th className="py-2 px-3">Zone</th>
              <th className="py-2 px-3">Category</th>
              <th className="py-2 px-3">Incident Event Description</th>
              <th className="py-2 px-3">Confidence</th>
              <th className="py-2 px-3">AI Recommendation</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredLogs.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-6 text-center text-slate-500 font-sans">
                  No logged events match the selected category filter.
                </td>
              </tr>
            ) : (
              filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">
                    {log.timestamp}
                  </td>
                  <td className="py-2.5 px-3 text-cyan-300 font-bold whitespace-nowrap">
                    {log.zone}
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                        log.category === 'congestion'
                          ? 'bg-rose-500/20 text-rose-300'
                          : log.category === 'anomaly'
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-cyan-500/20 text-cyan-300'
                      }`}
                    >
                      {log.category}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-200 font-sans font-medium">
                    {log.event}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">
                    {log.confidence}%
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans text-[11px]">
                    {log.recommendation || '—'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500">
        <span>Volatile memory ring buffer (Zero permanent storage).</span>
        <span>Audit compliant</span>
      </div>
    </div>
  );
};
