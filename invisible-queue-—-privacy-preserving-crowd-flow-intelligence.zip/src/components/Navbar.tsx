import React from 'react';
import { ENVIRONMENT_PRESETS } from '../config/presets';
import { EnvironmentPreset } from '../types/crowd';
import {
  ShieldCheck,
  Play,
  Presentation,
  BookOpen,
  Activity,
  Layers,
  Sparkles,
  Sliders,
  Shield,
  BarChart3,
  ListFilter,
  Monitor,
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  selectedPreset: EnvironmentPreset;
  onPresetChange: (preset: EnvironmentPreset) => void;
  onStartDemo: () => void;
  onOpenLinkedInModal: () => void;
  onOpenDocModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  selectedPreset,
  onPresetChange,
  onStartDemo,
  onOpenLinkedInModal,
  onOpenDocModal,
}) => {
  const tabs = [
    { id: 'monitor', label: 'Live Monitor', icon: Monitor },
    { id: 'analytics', label: 'Analytics', icon: Layers },
    { id: 'risk', label: 'Risk & Prediction', icon: Activity },
    { id: 'anomalies', label: 'Anomalies & AI', icon: Sparkles },
    { id: 'simulator', label: 'What-If Sandbox', icon: Sliders },
    { id: 'privacy', label: 'Privacy Mode', icon: Shield },
    { id: 'evaluation', label: 'Evaluation', icon: BarChart3 },
    { id: 'logs', label: 'Event Log', icon: ListFilter },
  ];

  return (
    <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-40">
      {/* Top Brand Row */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono font-black text-sm shadow-sm">
            IQ
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-extrabold tracking-wider text-white uppercase font-mono">
                Invisible Queue
              </h1>
              <span className="text-xs text-slate-500">·</span>
              <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Zero Biometrics</span>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Privacy-Preserving Crowd Flow Intelligence & Predictive Bottleneck Telemetry
            </p>
          </div>
        </div>

        {/* Center / Right Control Island */}
        <div className="flex items-center gap-2">
          {/* Environment Preset Selector */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-400 font-mono">
            <span>Preset:</span>
            <select
              value={selectedPreset.id}
              onChange={(e) => {
                const found = ENVIRONMENT_PRESETS.find((p) => p.id === e.target.value);
                if (found) onPresetChange(found);
              }}
              className="bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 text-xs focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              {ENVIRONMENT_PRESETS.map((preset) => (
                <option key={preset.id} value={preset.id}>
                  {preset.name}
                </option>
              ))}
            </select>
          </div>

          {/* START DEMO Button (Prominently visible as requested in Section 18) */}
          <button
            onClick={onStartDemo}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all active:scale-95"
            title="Instantly load and play an automated demonstration scenario"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>START DEMO</span>
          </button>

          {/* LinkedIn Mode Button */}
          <button
            onClick={onOpenLinkedInModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-medium transition-colors"
            title="Open 10-step LinkedIn & Academic presentation mode"
          >
            <Presentation className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">LinkedIn Mode</span>
          </button>

          {/* Docs Button */}
          <button
            onClick={onOpenDocModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 text-xs transition-colors"
            title="View README, architecture diagram, and Python script"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Docs</span>
          </button>
        </div>
      </div>

      {/* Primary Tab Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 border-t border-slate-900 overflow-x-auto">
        <nav className="flex items-center gap-1 py-1 text-xs">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-slate-900 text-cyan-300 font-semibold border border-slate-800 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
