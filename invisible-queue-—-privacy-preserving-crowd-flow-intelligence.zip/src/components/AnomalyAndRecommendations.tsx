import React from 'react';
import { AnomalyEvent, RecommendationItem } from '../types/crowd';
import {
  Activity,
  Bot,
  AlertOctagon,
  Sparkles,
  Info,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

interface AnomalyAndRecommendationsProps {
  anomalies: AnomalyEvent[];
  recommendations: RecommendationItem[];
}

export const AnomalyAndRecommendations: React.FC<AnomalyAndRecommendationsProps> = ({
  anomalies,
  recommendations,
}) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* 1. Anomaly Detection Feed */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                Unusual Movement Pattern Feed
              </h3>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">
              {anomalies.length} Logged
            </span>
          </div>

          <div className="mt-3 text-[11px] text-slate-400">
            Flags mathematical divergences in spatial velocity or density. Note:{' '}
            <strong className="text-slate-300">
              Not automatically designated as dangerous.
            </strong>
          </div>

          {/* List of Detected Anomalies */}
          <div className="mt-3 space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {anomalies.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-lg">
                No unusual movement patterns detected in recent frames.
              </div>
            ) : (
              anomalies.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-lg bg-slate-950/70 border border-slate-800/80 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                      <span className="text-xs font-mono font-semibold text-amber-300">
                        {item.patternLabel}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">
                      {item.timestamp} · {item.zoneName}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 mb-2 font-medium">
                    {item.description}
                  </p>

                  {/* Supporting measurements */}
                  <div className="grid grid-cols-2 gap-1.5 p-2 bg-slate-900/80 rounded border border-slate-800/60 text-[11px] font-mono">
                    {Object.entries(item.supportingMeasurements).map(([key, val]) => (
                      <div key={key} className="flex justify-between">
                        <span className="text-slate-500">{key}:</span>
                        <span className="text-slate-200 font-semibold">{String(val)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span>Algorithm Confidence: <strong className="text-cyan-400">{item.confidence}%</strong></span>
                    <span className="text-amber-400/90 font-semibold uppercase">UNUSUAL PATTERN</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-500 flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 shrink-0" />
          <span>Evidence-grounded pattern recognition; transparent diagnostic metrics.</span>
        </div>
      </div>

      {/* 2. AI Recommendation Engine */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                Operational AI Recommendations
              </h3>
            </div>
            <span className="text-[11px] text-cyan-400/90 font-mono font-medium">
              Autonomous Synthesizer
            </span>
          </div>

          <div className="mt-3 text-[11px] text-slate-400">
            Actionable crowd management guidance generated dynamically based on active bottlenecks.
          </div>

          {/* List of Recommendations */}
          <div className="mt-3 space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {recommendations.map((rec) => {
              const isUrgent = rec.level === 'urgent';
              const isAdvisory = rec.level === 'advisory';

              return (
                <div
                  key={rec.id}
                  className={`p-3 rounded-lg border transition-colors ${
                    isUrgent
                      ? 'bg-rose-950/20 border-rose-500/40 text-rose-100'
                      : isAdvisory
                      ? 'bg-amber-950/20 border-amber-500/40 text-amber-100'
                      : 'bg-slate-950/60 border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-semibold tracking-wide">
                      {rec.title}
                    </span>
                    <span
                      className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${
                        isUrgent
                          ? 'bg-rose-500/30 text-rose-300'
                          : isAdvisory
                          ? 'bg-amber-500/30 text-amber-300'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {rec.level}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 font-medium mb-1.5">
                    {rec.actionText}
                  </p>

                  <div className="text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded border border-slate-800/60 font-sans">
                    <strong className="text-slate-300">Operational Justification: </strong>
                    {rec.reasoning}
                  </div>

                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span>{rec.timestamp} · {rec.zoneName}</span>
                    <span className="text-cyan-400 font-semibold">{rec.disclaimer}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-500 flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
          <span>
            Advisory decision-support only; human venue operators retain ultimate operational control.
          </span>
        </div>
      </div>
    </div>
  );
};
