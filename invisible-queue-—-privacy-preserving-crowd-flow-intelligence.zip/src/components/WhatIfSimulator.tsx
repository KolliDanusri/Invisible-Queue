import React from 'react';
import { SimulationParameters, ZoneMetrics } from '../types/crowd';
import {
  Sliders,
  AlertTriangle,
  DoorClosed,
  Route,
  Ban,
  Maximize,
  ArrowRight,
  Sparkles,
  RotateCcw,
  CheckCircle,
} from 'lucide-react';

interface WhatIfSimulatorProps {
  params: SimulationParameters;
  onUpdateParams: (newParams: Partial<SimulationParameters>) => void;
  zoneMetrics: ZoneMetrics[];
  onResetParams: () => void;
}

export const WhatIfSimulator: React.FC<WhatIfSimulatorProps> = ({
  params,
  onUpdateParams,
  zoneMetrics,
  onResetParams,
}) => {
  // Estimated impact modeling
  const estimatedCongestionRisk =
    params.entranceClosed && !params.alternatePathOpen
      ? 'CRITICAL (Upstream Queue Accumulation)'
      : params.alternatePathOpen
      ? 'STABILIZED (Flow Distributed via Pathway D)'
      : params.zoneBRestricted
      ? 'ELEVATED (South Diverted Surge)'
      : params.spawnRate > 3.0
      ? 'HIGH-RISK (Inflow Exceeds Egress Capacity)'
      : 'NOMINAL';

  const zoneBDensityEst = params.zoneBRestricted
    ? Math.max(5, (zoneMetrics?.find((z) => z && z.zoneId === 'zone-b')?.density ?? 50) - 35)
    : params.spawnRate > 3.0
    ? Math.min(100, (zoneMetrics?.find((z) => z && z.zoneId === 'zone-b')?.density ?? 50) + 30)
    : zoneMetrics?.find((z) => z && z.zoneId === 'zone-b')?.density ?? 45;

  const zoneDDensityEst = params.alternatePathOpen
    ? Math.min(100, (zoneMetrics?.find((z) => z && z.zoneId === 'zone-d')?.density ?? 30) + 28)
    : zoneMetrics?.find((z) => z && z.zoneId === 'zone-d')?.density ?? 25;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col gap-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              Interactive What-If Scenario Sandbox
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Simulate physical geometry changes, turnstile closures, and alternate corridors to test crowd behavior.
          </p>
        </div>

        <button
          onClick={onResetParams}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 transition-colors border border-slate-700"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset Parameters
        </button>
      </div>

      {/* Mandatory Honesty Warning Banner */}
      <div className="p-3 rounded-lg bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs flex items-center gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
        <div>
          <span className="font-extrabold uppercase tracking-wider block font-mono text-[11px]">
            SIMULATION — NOT A GUARANTEED REAL-WORLD PREDICTION
          </span>
          <span className="text-amber-300/80 text-[11px]">
            Synthetic agent modeling demonstrates theoretical physics under controlled assumptions. Real human crowd dynamics require site-specific operational testing.
          </span>
        </div>
      </div>

      {/* Sandbox Controls Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Toggle 1: Close Entrance */}
        <div className="p-3.5 rounded-lg bg-slate-950/60 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-200">Main Entrance Inflow</span>
              <DoorClosed className="w-4 h-4 text-cyan-400" />
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Chokes turnstiles at Zone A, stopping all new simulated arrivals.
            </p>
          </div>
          <button
            onClick={() => onUpdateParams({ entranceClosed: !params.entranceClosed })}
            className={`w-full py-2 px-3 rounded text-xs font-bold font-mono transition-colors border ${
              params.entranceClosed
                ? 'bg-rose-500 text-white border-rose-600 shadow-sm'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            {params.entranceClosed ? 'ENTRANCE CLOSED' : 'ENTRANCE OPEN'}
          </button>
        </div>

        {/* Toggle 2: Open Alternate Pathway */}
        <div className="p-3.5 rounded-lg bg-slate-950/60 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-200">Alternate Corridor</span>
              <Route className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Opens secondary bypass through Zone D, siphoning 50% of traffic.
            </p>
          </div>
          <button
            onClick={() => onUpdateParams({ alternatePathOpen: !params.alternatePathOpen })}
            className={`w-full py-2 px-3 rounded text-xs font-bold font-mono transition-colors border ${
              params.alternatePathOpen
                ? 'bg-emerald-500 text-slate-950 border-emerald-600 shadow-sm'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            {params.alternatePathOpen ? 'BYPASS ACTIVE' : 'OPEN ALTERNATE PATH'}
          </button>
        </div>

        {/* Toggle 3: Restrict Zone B */}
        <div className="p-3.5 rounded-lg bg-slate-950/60 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-200">Zone B Concourse</span>
              <Ban className="w-4 h-4 text-amber-400" />
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Applies dynamic barrier to divert pedestrian agents around the central bottleneck.
            </p>
          </div>
          <button
            onClick={() => onUpdateParams({ zoneBRestricted: !params.zoneBRestricted })}
            className={`w-full py-2 px-3 rounded text-xs font-bold font-mono transition-colors border ${
              params.zoneBRestricted
                ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-sm'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            {params.zoneBRestricted ? 'ZONE B RESTRICTED' : 'ALLOW ZONE B ACCESS'}
          </button>
        </div>

        {/* Sliders: Incoming Flow Rate */}
        <div className="p-3.5 rounded-lg bg-slate-950/60 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-200">Incoming Flow Spawn Rate</span>
              <span className="text-xs font-mono text-cyan-400 font-bold">
                {params.spawnRate.toFixed(1)}/s
              </span>
            </div>
            <input
              type="range"
              min="0.2"
              max="5.0"
              step="0.2"
              value={params.spawnRate}
              onChange={(e) => onUpdateParams({ spawnRate: parseFloat(e.target.value) })}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>
          <div className="mt-3 flex justify-between text-[10px] text-slate-500 font-mono">
            <span>Low (0.2/s)</span>
            <span>Medium (2.0/s)</span>
            <span>Surge (5.0/s)</span>
          </div>
        </div>
      </div>

      {/* Simulated Outcomes Matrix */}
      <div className="p-4 rounded-lg bg-slate-950/70 border border-slate-800">
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-2 font-mono">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          Projected Mathematical Simulation Outcomes:
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[11px] block">Projected Overall Risk</span>
            <span className="text-sm font-bold font-mono text-cyan-300 mt-1 block">
              {estimatedCongestionRisk}
            </span>
          </div>

          <div className="p-3 rounded bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[11px] block">Zone B Projected Density</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm font-bold font-mono text-white">
                {zoneBDensityEst}%
              </span>
              <span className="text-[10px] text-slate-500">
                {params.zoneBRestricted ? '(-35% diverted)' : '(nominal)'}
              </span>
            </div>
          </div>

          <div className="p-3 rounded bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[11px] block">Zone D Bypass Absorption</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm font-bold font-mono text-white">
                {zoneDDensityEst}%
              </span>
              <span className="text-[10px] text-slate-500">
                {params.alternatePathOpen ? '(+28% relief flow)' : '(idle)'}
              </span>
            </div>
          </div>

          <div className="p-3 rounded bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[11px] block">Simulated Flow Direction</span>
            <span className="text-sm font-bold font-mono text-sky-400 mt-1 block">
              {params.alternatePathOpen ? 'Bi-Corridor Divergent' : 'Uni-Directional East'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
