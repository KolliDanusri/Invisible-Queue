import React from 'react';
import { CongestionAssessment, CongestionSignalEvidence, PredictionResult } from '../types/crowd';
import {
  AlertCircle,
  TrendingUp,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Compass,
} from 'lucide-react';

interface RiskPredictionPanelProps {
  congestion: CongestionAssessment;
  prediction: PredictionResult;
}

export const RiskPredictionPanel: React.FC<RiskPredictionPanelProps> = ({
  congestion,
  prediction,
}) => {
  const isHighRisk = congestion.overallState === 'HIGH-RISK CONGESTION';
  const isIncreasing = congestion.overallState === 'INCREASING';

  const predIsHigh = prediction.level === 'HIGH-RISK';
  const predIsInc = prediction.level === 'INCREASING';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* 1. Multi-Signal Congestion Detection State */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                Multi-Signal Congestion State
              </h3>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">
              Score: {congestion.score}/100
            </span>
          </div>

          {/* Large State Indicator */}
          <div className="mt-4 p-3 rounded-lg bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                Current Condition
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                {isHighRisk ? (
                  <AlertCircle className="w-5 h-5 text-rose-500 animate-pulse" />
                ) : isIncreasing ? (
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                )}
                <span
                  className={`text-lg font-extrabold font-mono tracking-wide ${
                    isHighRisk
                      ? 'text-rose-400'
                      : isIncreasing
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {congestion.overallState}
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-500 font-mono block">CRITICAL ZONE</span>
              <span className="text-xs font-mono font-bold text-slate-300 uppercase">
                {congestion.dominantZoneId}
              </span>
            </div>
          </div>

          {/* Supporting Evidence Breakdown */}
          <div className="mt-4">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Supporting Diagnostic Evidence (Density Alone Not Used):
            </span>
            <div className="space-y-1.5">
              {congestion.evidence.map((item: CongestionSignalEvidence, idx: number) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 rounded bg-slate-950/40 text-xs border border-slate-800/60"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        item.status === 'critical'
                          ? 'bg-rose-500'
                          : item.status === 'warning'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                    />
                    <span className="text-slate-300 font-medium">{item.metric}:</span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-slate-200">{item.value}</span>
                    <span className="text-slate-500 text-[10px] ml-2">({item.impact})</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Reason summary text */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
          <strong className="text-slate-300">Synthesized Findings: </strong>
          {congestion.reasons.join(' · ')}
        </div>
      </div>

      {/* 2. Early Congestion Time-Series Prediction */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                Early Congestion Prediction (Forward Horizon)
              </h3>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">
              Lookahead: +{prediction.timeHorizonSec}s
            </span>
          </div>

          {/* Prediction Status Badge */}
          <div className="mt-4 p-3 rounded-lg bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                Forecasted Tendency (+{prediction.timeHorizonSec}s)
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <Compass className="w-5 h-5 text-cyan-400" />
                <span
                  className={`text-lg font-extrabold font-mono tracking-wide ${
                    predIsHigh
                      ? 'text-rose-400'
                      : predIsInc
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  PREDICTED: {prediction.level}
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-500 font-mono block">MODEL CONFIDENCE</span>
              <span
                className={`text-sm font-mono font-bold ${
                  prediction.isLowConfidence ? 'text-amber-400' : 'text-cyan-400'
                }`}
              >
                {prediction.confidence}%
              </span>
            </div>
          </div>

          {/* Low Confidence Guardrail Warning */}
          {prediction.isLowConfidence && (
            <div className="mt-3 p-2.5 rounded bg-amber-950/50 border border-amber-500/30 text-xs text-amber-200 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="block font-semibold">Prediction confidence is low.</strong>
                <span className="text-[11px] text-amber-300/80">
                  {prediction.lowConfidenceReason ||
                    'Uncertainty is elevated due to volatile flow variance. Operating under reduced certainty model.'}
                </span>
              </div>
            </div>
          )}

          {/* Trend Metrics & Contributing Factors */}
          <div className="mt-3 space-y-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded bg-slate-950/40 border border-slate-800/60 font-mono">
              <span className="text-slate-400">Density Trend Velocity:</span>
              <span className={prediction.trendVelocity > 0 ? 'text-amber-400' : 'text-emerald-400'}>
                {prediction.trendVelocity > 0 ? `+${prediction.trendVelocity}` : prediction.trendVelocity}% / min
              </span>
            </div>

            <div className="flex items-center justify-between p-2 rounded bg-slate-950/40 border border-slate-800/60 font-mono">
              <span className="text-slate-400">Projected System Headcount:</span>
              <span className="text-slate-200">
                ~{prediction.projectedCountInHorizon} occupants
              </span>
            </div>

            <div className="pt-2">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                Influencing Extrapolation Factors:
              </span>
              <ul className="space-y-1 text-slate-300 text-[11px]">
                {prediction.contributingFactors.map((factor, idx) => (
                  <li key={idx} className="flex items-center gap-1.5">
                    <span className="text-cyan-500">›</span>
                    <span>{factor}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Honesty & Safety Disclaimer */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-1.5 text-[11px] text-slate-500">
          <HelpCircle className="w-3.5 h-3.5 shrink-0" />
          <span>
            Predictions are mathematical extrapolations of rolling velocity vectors; never guaranteed.
          </span>
        </div>
      </div>
    </div>
  );
};
