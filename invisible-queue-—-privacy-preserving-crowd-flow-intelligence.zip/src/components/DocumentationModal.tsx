import React, { useState } from 'react';
import {
  BookOpen,
  X,
  Copy,
  Terminal,
  FileText,
  Code,
  Layers,
  Shield,
  HelpCircle,
} from 'lucide-react';

interface DocumentationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DocumentationModal: React.FC<DocumentationModalProps> = ({ isOpen, onClose }) => {
  const [activeDocTab, setActiveDocTab] = useState<'readme' | 'python' | 'architecture' | 'api' | 'limitations'>('readme');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const readmeContent = `# INVISIBLE QUEUE — Privacy-Preserving Crowd Flow Intelligence

A real-time AI computer vision system designed to detect, track, understand, and predict crowd congestion without identifying people.

## 🚀 Quick Startup

\`\`\`bash
# 1. Clone repository
git clone https://github.com/example/invisible-queue.git
cd invisible-queue

# 2. Install dependencies
npm install

# 3. Launch live web client
npm run dev
# Browser opens at http://localhost:3000
\`\`\`

## 🛡️ Core Privacy Invariant
- **Zero Facial Recognition**: No face detection or landmark models loaded.
- **Zero Biometric Footprint**: No embeddings, demographics, or identity classification.
- **Temporary Tracking Only**: Tracks receive ephemeral tokens (e.g. \`Person-01\`) that are purged from volatile RAM the second an individual departs the frame.
- **Zero Raw Video Storage**: Frame analysis happens in browser/server memory; no frames written to persistent disk.

## 🔬 Pipeline Flow
Camera / Video Stream
      ↓
Person Detection (Luminance delta / Optical Flow / YOLO)
      ↓
Anonymous Multi-Person Tracking (ByteTrack / IoU association)
      ↓
Dynamic Zone Analysis (Ray-casting polygon containment)
      ↓
Density + Flow Analysis (Opposing vector conflict scoring)
      ↓
Multi-Signal Congestion Engine (Density + Speed + Conflict + Net Inflow)
      ↓
Early Congestion Prediction (90s forward regression lookahead)
      ↓
Anomaly Detection ("Unusual movement pattern detected")
      ↓
Operational AI Recommendations ("AI-generated suggestions")
      ↓
Interactive Dashboard + What-If Simulation Sandbox`;

  const pythonBackendContent = `# backend/app.py
# Optional Standalone Python Backend using FastAPI + OpenCV + ByteTrack / YOLO
from fastapi import FastAPI, UploadFile, File, WebSocket
from fastapi.middleware.cors import CORSMiddleware
import cv2
import numpy as np
import time

app = FastAPI(title="Invisible Queue CV Engine", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class AnonymousTracker:
    def __init__(self):
        self.next_id = 1
        self.tracks = {}

    def update(self, detections):
        # Bipartite matching with IoU
        # Assign ephemeral anonymous token: f"Person-{self.next_id:02d}"
        # Expire tracks after 30 lost frames
        return []

tracker = AnonymousTracker()

@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "privacy": "strictly_anonymous",
        "models": ["yolov8n", "bytetrack_anonymous"]
    }

@app.post("/api/analyze-frame")
async def analyze_frame(file: UploadFile = File(...)):
    contents = await file.read()
    nparr = np.frombuffer(contents, np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    # 1. Detect person blobs (HOG or YOLO without face recognition)
    # 2. Track with anonymous IDs
    # 3. Calculate zone densities and vector conflicts
    
    return {
        "active_tracks": 14,
        "congestion_state": "NORMAL",
        "privacy_verified": True
    }`;

  const architectureText = `========================================================================
INVISIBLE QUEUE ARCHITECTURE DIAGRAM
========================================================================

 [Camera Feed / Video / Synthetic Canvas]
                  │
                  ▼
       ┌────────────────────────┐
       │   Person Detection     │  <-- Downscaled Luminance Delta &
       │   (Real-time CV)       │      Clustering (Zero Face Landmark)
       └──────────┬─────────────┘
                  │
                  ▼
       ┌────────────────────────┐
       │ Anonymous Multi-Person │  <-- ByteTrack Association + IoU +
       │ Tracking Engine        │      Volatile Tokens (Person-01..N)
       └──────────┬─────────────┘
                  │
                  ▼
       ┌────────────────────────┐
       │ Dynamic Zone Analysis  │  <-- Polygon Ray-Casting Partition
       │ & Flow Vector Metric   │      (Inflow, Outflow, Dwell, Speed)
       └──────────┬─────────────┘
                  │
                  ▼
       ┌────────────────────────┐
       │ Multi-Signal Congestion│  <-- Combines 5 Signals (Density Alone
       │ Engine                 │      NOT Used) -> State: NORMAL / INC / HIGH
       └──────────┬─────────────┘
                  │
                  ├───────────────────────────────┐
                  ▼                               ▼
       ┌────────────────────────┐      ┌────────────────────────┐
       │ Early Prediction Engine│      │ Anomaly Detection      │
       │ (90s Horizon Linear)   │      │ ("Unusual Movement")   │
       └──────────┬─────────────┘      └──────────┬─────────────┘
                  │                               │
                  └───────────────┬───────────────┘
                                  ▼
                       ┌────────────────────────┐
                       │ Operational AI         │
                       │ Recommendations        │
                       └──────────┬─────────────┘
                                  │
                                  ▼
                       ┌────────────────────────┐
                       │  Operator Dashboard    │
                       │  & What-If Simulator   │
                       └────────────────────────┘`;

  const limitationsText = `## ⚠️ Honest Engineering Limitations & Future Roadmap

### Real-World Challenges & Current Mitigations
1. **Severe Crowd Overlap (Occlusion)**:
   - *Limitation*: Heavy crowd compression can merge adjacent bounding boxes into single detection blobs.
   - *Mitigation*: Our tracker implements a 30-frame temporal track persistence buffer and flags overlap ratios, reducing confidence score rather than hallucinating individual precision.

2. **Low-Light Scenarios**:
   - *Limitation*: Optical sensor signal-to-noise ratio drops in dim concourses, reducing detection accuracy.
   - *Mitigation*: Integrated average luminance meter. When brightness drops below 40/255, system triggers: "LOW CONFIDENCE: Improve lighting or reposition camera".

3. **Camera Angle & Perspective Distortion**:
   - *Limitation*: Oblique camera angles distort real-world distance metrics (m/s).
   - *Mitigation*: Configurable zone polygon boundaries and environment presets (Station, Mall, Stadium).

4. **Prediction Horizon Bound**:
   - *Limitation*: Future crowd behavior cannot be known with 100% deterministic certainty.
   - *Mitigation*: Prediction engine enforces confidence intervals and displays: "SIMULATION — NOT A GUARANTEED REAL-WORLD PREDICTION".

### Future Work Roadmap
- Multi-camera homography matrix fusion across non-overlapping topological zones.
- Edge TPU / WebGPU acceleration for embedded IoT camera deployment.
- Formal academic benchmarking on MOT20 and CrowdHuman datasets.`;

  const copyDoc = (content: string) => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white tracking-wide">
              Engineering Documentation & Source Reference
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1 px-6 pt-3 bg-slate-950/60 border-b border-slate-800 text-xs font-mono">
          {[
            { id: 'readme', label: 'README.md' },
            { id: 'architecture', label: 'Architecture Diagram' },
            { id: 'python', label: 'backend/app.py' },
            { id: 'limitations', label: 'Limitations & Future Work' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveDocTab(tab.id as any)}
              className={`px-3 py-2 border-b-2 transition-colors ${
                activeDocTab === tab.id
                  ? 'border-cyan-400 text-cyan-300 font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto">
          {activeDocTab === 'readme' && (
            <div className="space-y-4">
              <div className="flex justify-end">
                <button
                  onClick={() => copyDoc(readmeContent)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 font-mono transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copied ? 'Copied!' : 'Copy README'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 font-mono text-xs leading-relaxed whitespace-pre-wrap">
                {readmeContent}
              </pre>
            </div>
          )}

          {activeDocTab === 'architecture' && (
            <div className="space-y-4">
              <div className="flex justify-end">
                <button
                  onClick={() => copyDoc(architectureText)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 font-mono transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copied ? 'Copied!' : 'Copy ASCII Diagram'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-cyan-400 font-mono text-xs leading-relaxed whitespace-pre overflow-x-auto">
                {architectureText}
              </pre>
            </div>
          )}

          {activeDocTab === 'python' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  FastAPI + OpenCV backend server blueprint for native Python deployments.
                </span>
                <button
                  onClick={() => copyDoc(pythonBackendContent)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 font-mono transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copied ? 'Copied!' : 'Copy Python Script'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 font-mono text-xs leading-relaxed whitespace-pre-wrap">
                {pythonBackendContent}
              </pre>
            </div>
          )}

          {activeDocTab === 'limitations' && (
            <div className="space-y-4">
              <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 font-mono text-xs leading-relaxed whitespace-pre-wrap">
                {limitationsText}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
