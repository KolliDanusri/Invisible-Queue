import React from 'react';
import { PrivacyConfig } from '../types/crowd';
import {
  ShieldCheck,
  Lock,
  EyeOff,
  Trash2,
  CheckCircle2,
  FileCheck,
  AlertCircle,
  DatabaseZap,
} from 'lucide-react';

interface PrivacyPanelProps {
  config: PrivacyConfig;
  onUpdateConfig: (newConfig: Partial<PrivacyConfig>) => void;
  onPurgeTemporaryTracks: () => void;
  activeTrackCount: number;
}

export const PrivacyPanel: React.FC<PrivacyPanelProps> = ({
  config,
  onUpdateConfig,
  onPurgeTemporaryTracks,
  activeTrackCount,
}) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col gap-6">
      {/* Title */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              Privacy-by-Design Architecture & Controls
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Strict algorithmic safeguards guaranteeing mathematical anonymity without biometric ingestion.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onPurgeTemporaryTracks}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs transition-colors font-mono"
            title="Instantly clear all volatile in-memory trajectory buffers"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Purge Ephemeral Memory ({activeTrackCount} active)
          </button>
        </div>
      </div>

      {/* 5 Core Privacy Guarantees Banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { title: 'No Face Recognition', desc: 'Zero facial landmarking or feature extraction models installed.' },
          { title: 'No Identity Recognition', desc: 'No biometric database, embeddings, or demographic categorizers.' },
          { title: 'No Permanent Person IDs', desc: 'Temporary IDs expire and are garbage-collected immediately.' },
          { title: 'Anonymous Temporary Tracking', desc: 'Track tokens (Person-XX) exist solely while in frame.' },
          { title: 'No Raw Footage Stored', desc: 'Frames processed in volatile RAM; zero disk writes by default.' },
        ].map((item, idx) => (
          <div
            key={idx}
            className="p-3 rounded-lg bg-slate-950/70 border border-emerald-500/20 flex flex-col justify-between"
          >
            <div className="flex items-center gap-2 mb-2 text-emerald-400">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span className="text-xs font-bold">{item.title}</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>

      {/* Visual Anonymization & Obfuscation Filters */}
      <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-2 font-mono">
          <EyeOff className="w-4 h-4 text-cyan-400" />
          Client-Side Visual Obfuscation Filters:
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {[
            {
              id: 'none',
              label: 'Standard Stream',
              desc: 'Raw camera pixels visible behind bounding boxes.',
            },
            {
              id: 'face_only',
              label: 'Face Pixelation Mask',
              desc: 'Digital privacy mask over the upper head/face region.',
            },
            {
              id: 'full_silhouette',
              label: 'Full Silhouette Blur',
              desc: 'Gaussian blur on background, anonymizing all visual details.',
            },
            {
              id: 'abstract_skeleton',
              label: 'Abstract Wireframe Only',
              desc: 'Human bodies replaced with non-identifiable wireframes.',
            },
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => onUpdateConfig({ blurLevel: mode.id as any })}
              className={`p-3 rounded-lg text-left transition-all border ${
                config.blurLevel === mode.id
                  ? 'bg-cyan-500/15 border-cyan-500 text-white shadow-sm'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="text-xs font-bold block mb-1 font-mono">
                {mode.label}
              </span>
              <span className="text-[11px] text-slate-400 leading-relaxed block">
                {mode.desc}
              </span>
            </button>
          ))}
        </div>

        {/* Additional Privacy Toggles */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <label className="flex items-center gap-3 cursor-pointer p-2.5 rounded bg-slate-900 border border-slate-800">
            <input
              type="checkbox"
              checked={config.hideRawVideo}
              onChange={(e) => onUpdateConfig({ hideRawVideo: e.target.checked })}
              className="accent-cyan-400 w-4 h-4"
            />
            <div>
              <span className="font-semibold text-slate-200 block">
                Complete Feed Occlusion (Radar Only Mode)
              </span>
              <span className="text-[11px] text-slate-400">
                Replaces underlying camera video with purely abstract telemetry canvas.
              </span>
            </div>
          </label>

          <label className="flex items-center gap-3 cursor-pointer p-2.5 rounded bg-slate-900 border border-slate-800">
            <input
              type="checkbox"
              checked={config.anonymousBoundingBoxesOnly}
              onChange={(e) => onUpdateConfig({ anonymousBoundingBoxesOnly: e.target.checked })}
              className="accent-cyan-400 w-4 h-4"
            />
            <div>
              <span className="font-semibold text-slate-200 block">
                Strict Anonymous Identifiers
              </span>
              <span className="text-[11px] text-slate-400">
                Restricts labels to temporary ephemeral identifiers (e.g. Person-01).
              </span>
            </div>
          </label>
        </div>
      </div>

      {/* Compliance & Audit Verification */}
      <div className="p-3.5 rounded-lg bg-emerald-950/20 border border-emerald-500/30 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2.5 text-emerald-300">
          <FileCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>
            GDPR / CCPA Non-PII Compliant Architecture Verified: Zero biometric retention vector.
          </span>
        </div>
        <span className="font-mono text-emerald-400 font-semibold text-[11px]">
          STATUS: VERIFIED SECURE
        </span>
      </div>
    </div>
  );
};
