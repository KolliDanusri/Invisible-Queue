import React, { useEffect, useRef, useState } from 'react';
import {
  AnonymousPersonTrack,
  FlowVector,
  PrivacyConfig,
  ScenarioType,
  SystemHealthMetrics,
  ZoneDefinition,
  ZoneMetrics,
} from '../types/crowd';
import { HeatmapRenderer } from '../analytics/heatmap';
import {
  Eye,
  EyeOff,
  Flame,
  Maximize2,
  Navigation,
  Shield,
  Video,
  Camera,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  Info,
} from 'lucide-react';

interface LiveMonitorProps {
  tracks: AnonymousPersonTrack[];
  zones: ZoneDefinition[];
  zoneMetrics: ZoneMetrics[];
  flowVectors: FlowVector[];
  systemHealth: SystemHealthMetrics;
  privacyConfig: PrivacyConfig;
  currentScenario: ScenarioType;
  inputMode: 'synthetic' | 'webcam' | 'video';
  onScenarioChange: (scenario: ScenarioType) => void;
  onInputModeChange: (mode: 'synthetic' | 'webcam' | 'video') => void;
  onPrivacyToggle: (key: keyof PrivacyConfig, val: any) => void;
  onReset: () => void;
  renderBackgroundCanvas?: (ctx: CanvasRenderingContext2D, privacyBlur: boolean) => void;
  webcamVideoRef: React.RefObject<HTMLVideoElement | null>;
  uploadedVideoRef: React.RefObject<HTMLVideoElement | null>;
  onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const LiveMonitor: React.FC<LiveMonitorProps> = ({
  tracks,
  zones,
  zoneMetrics,
  flowVectors,
  systemHealth,
  privacyConfig,
  currentScenario,
  inputMode,
  onScenarioChange,
  onInputModeChange,
  onPrivacyToggle,
  onReset,
  renderBackgroundCanvas,
  webcamVideoRef,
  uploadedVideoRef,
  onFileUpload,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const heatmapRendererRef = useRef<HeatmapRenderer | null>(null);

  // Overlay display states
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [showFlowVectors, setShowFlowVectors] = useState(true);
  const [showZones, setShowZones] = useState(true);
  const [showBoundingBoxes, setShowBoundingBoxes] = useState(true);
  const [showIds, setShowIds] = useState(true);
  const [showTrails, setShowTrails] = useState(true);

  // Initialize heatmap renderer
  useEffect(() => {
    heatmapRendererRef.current = new HeatmapRenderer(800, 500);
  }, []);

  // Main drawing loop on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // 1. Render Background (Webcam, uploaded video, or synthetic simulation)
    const isPrivacyBlur = privacyConfig.blurLevel !== 'none';

    if (inputMode === 'synthetic') {
      if (renderBackgroundCanvas) {
        renderBackgroundCanvas(ctx, isPrivacyBlur);
      }
    } else if (inputMode === 'webcam' && webcamVideoRef.current && webcamVideoRef.current.readyState >= 2) {
      ctx.save();
      if (privacyConfig.hideRawVideo) {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, width, height);
      } else {
        if (privacyConfig.blurLevel === 'full_silhouette' || privacyConfig.blurLevel === 'face_only') {
          ctx.filter = 'blur(10px) contrast(120%)';
        }
        ctx.drawImage(webcamVideoRef.current, 0, 0, width, height);
      }
      ctx.restore();
    } else if (inputMode === 'video' && uploadedVideoRef.current && uploadedVideoRef.current.readyState >= 2) {
      ctx.save();
      if (privacyConfig.hideRawVideo) {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, width, height);
      } else {
        if (privacyConfig.blurLevel === 'full_silhouette' || privacyConfig.blurLevel === 'face_only') {
          ctx.filter = 'blur(10px) contrast(120%)';
        }
        ctx.drawImage(uploadedVideoRef.current, 0, 0, width, height);
      }
      ctx.restore();
    } else {
      // Standby / awaiting video
      ctx.fillStyle = '#0b0f19';
      ctx.fillRect(0, 0, width, height);
    }

    // 2. Render Live Density Heatmap Overlay
    if (showHeatmap && heatmapRendererRef.current) {
      heatmapRendererRef.current.render(ctx, tracks, width, height, 0.65);
    }

    // 3. Render Dynamic Zone Boundaries & HUD Overlays
    if (showZones) {
      zones.forEach((zone) => {
        const poly = zone.polygon;
        if (poly.length < 3) return;

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(poly[0].x * width, poly[0].y * height);
        for (let i = 1; i < poly.length; i++) {
          ctx.lineTo(poly[i].x * width, poly[i].y * height);
        }
        ctx.closePath();

        const metrics = zoneMetrics?.find((zm) => zm && zm.zoneId === zone?.id);
        const isCritical = metrics?.congestionRisk === 'HIGH-RISK CONGESTION';
        const isIncreasing = metrics?.congestionRisk === 'INCREASING';

        // Zone Fill tint
        let fillStyle = 'rgba(15, 23, 42, 0.2)';
        if (zone.isRestricted) fillStyle = 'rgba(239, 68, 68, 0.22)';
        else if (isCritical) fillStyle = 'rgba(239, 68, 68, 0.15)';
        else if (isIncreasing) fillStyle = 'rgba(245, 158, 11, 0.12)';

        ctx.fillStyle = fillStyle;
        ctx.fill();

        // Zone border outline
        ctx.lineWidth = isCritical ? 2.5 : 1.5;
        ctx.strokeStyle = isCritical ? '#ef4444' : isIncreasing ? '#f59e0b' : zone.color;
        ctx.setLineDash([4, 4]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Zone Tag Badge
        const tagX = poly[0].x * width + 8;
        const tagY = poly[0].y * height + 18;

        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(tagX, tagY - 14, 115, 24, 4);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = zone.color;
        ctx.font = '600 10px "JetBrains Mono", monospace';
        ctx.fillText(zone.code, tagX + 6, tagY);

        ctx.fillStyle = '#f8fafc';
        ctx.font = '500 10px "Plus Jakarta Sans", sans-serif';
        const countTxt = `${metrics?.currentCount ?? 0} pers · ${metrics?.density ?? 0}%`;
        ctx.fillText(countTxt, tagX + 48, tagY);

        ctx.restore();
      });
    }

    // 4. Render Movement Flow Vectors / Arrows
    if (showFlowVectors) {
      ctx.save();
      for (const vec of flowVectors) {
        ctx.beginPath();
        ctx.moveTo(vec.startX, vec.startY);
        ctx.lineTo(vec.endX, vec.endY);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Arrow head
        const headLength = 7;
        const angle = Math.atan2(vec.endY - vec.startY, vec.endX - vec.startX);
        ctx.beginPath();
        ctx.moveTo(vec.endX, vec.endY);
        ctx.lineTo(
          vec.endX - headLength * Math.cos(angle - Math.PI / 6),
          vec.endY - headLength * Math.sin(angle - Math.PI / 6)
        );
        ctx.lineTo(
          vec.endX - headLength * Math.cos(angle + Math.PI / 6),
          vec.endY - headLength * Math.sin(angle + Math.PI / 6)
        );
        ctx.closePath();
        ctx.fillStyle = '#38bdf8';
        ctx.fill();
      }
      ctx.restore();
    }

    // 5. Render Anonymous Person Tracks & Bounding Boxes
    tracks.forEach((track) => {
      const { bbox, color, id, confidence, isOverlapping, state } = track;
      const cx = bbox.x + bbox.width / 2;
      const cy = bbox.y + bbox.height / 2;

      // Trajectory history trail
      if (showTrails && track.history.length > 1) {
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(track.history[0].x, track.history[0].y);
        for (let i = 1; i < track.history.length; i++) {
          ctx.lineTo(track.history[i].x, track.history[i].y);
        }
        ctx.strokeStyle = color;
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();
      }

      // Privacy: Abstract Skeleton Mode
      if (privacyConfig.blurLevel === 'abstract_skeleton') {
        ctx.save();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        // Head circle
        ctx.beginPath();
        ctx.arc(cx, bbox.y + 12, 6, 0, Math.PI * 2);
        ctx.stroke();
        // Spine
        ctx.beginPath();
        ctx.moveTo(cx, bbox.y + 18);
        ctx.lineTo(cx, bbox.y + bbox.height * 0.65);
        ctx.stroke();
        // Arms
        ctx.beginPath();
        ctx.moveTo(cx - 10, bbox.y + 26);
        ctx.lineTo(cx + 10, bbox.y + 26);
        ctx.stroke();
        // Legs
        ctx.beginPath();
        ctx.moveTo(cx, bbox.y + bbox.height * 0.65);
        ctx.lineTo(cx - 8, bbox.y + bbox.height);
        ctx.moveTo(cx, bbox.y + bbox.height * 0.65);
        ctx.lineTo(cx + 8, bbox.y + bbox.height);
        ctx.stroke();
        ctx.restore();
      }

      // Privacy: Face blur / pixelation overlay on head region
      if (privacyConfig.blurLevel === 'face_only') {
        ctx.save();
        const headW = Math.min(bbox.width * 0.5, 20);
        const headH = 18;
        const headX = cx - headW / 2;
        const headY = bbox.y + 2;
        ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
        ctx.beginPath();
        ctx.ellipse(cx, headY + 8, headW / 2, headH / 2, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Anonymous Bounding Box
      if (showBoundingBoxes) {
        ctx.save();
        const isLost = state === 'lost';
        const boxColor = isOverlapping ? '#f59e0b' : color;

        ctx.strokeStyle = boxColor;
        ctx.lineWidth = isOverlapping ? 2 : 1.5;
        if (isLost) {
          ctx.setLineDash([3, 3]);
        }

        // Clean corner brackets or full box
        ctx.strokeRect(bbox.x, bbox.y, bbox.width, bbox.height);
        ctx.setLineDash([]);

        // Temporary Anonymous ID Label (e.g. Person-01)
        if (showIds) {
          const label = id;
          const confText = `${Math.round(confidence * 100)}%`;

          ctx.font = '600 10px "JetBrains Mono", monospace';
          const textW = ctx.measureText(`${label} · ${confText}`).width;

          ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
          ctx.beginPath();
          ctx.roundRect(bbox.x, bbox.y - 18, textW + 12, 16, 3);
          ctx.fill();

          ctx.fillStyle = isOverlapping ? '#f59e0b' : '#38bdf8';
          ctx.fillText(label, bbox.x + 4, bbox.y - 6);

          ctx.fillStyle = '#94a3b8';
          ctx.fillText(`· ${confText}`, bbox.x + 6 + ctx.measureText(label).width, bbox.y - 6);
        }

        ctx.restore();
      }
    });

    // 6. Draw HUD Scanner Grid Overlay corners
    ctx.save();
    ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
    ctx.lineWidth = 2;
    const cornerSize = 14;
    // Top-left
    ctx.beginPath();
    ctx.moveTo(10, 10 + cornerSize);
    ctx.lineTo(10, 10);
    ctx.lineTo(10 + cornerSize, 10);
    ctx.stroke();
    // Top-right
    ctx.beginPath();
    ctx.moveTo(width - 10 - cornerSize, 10);
    ctx.lineTo(width - 10, 10);
    ctx.lineTo(width - 10, 10 + cornerSize);
    ctx.stroke();
    // Bottom-left
    ctx.beginPath();
    ctx.moveTo(10, height - 10 - cornerSize);
    ctx.lineTo(10, height - 10);
    ctx.lineTo(10 + cornerSize, height - 10);
    ctx.stroke();
    // Bottom-right
    ctx.beginPath();
    ctx.moveTo(width - 10 - cornerSize, height - 10);
    ctx.lineTo(width - 10, height - 10);
    ctx.lineTo(width - 10, height - 10 - cornerSize);
    ctx.stroke();
    ctx.restore();
  }, [
    tracks,
    zones,
    zoneMetrics,
    flowVectors,
    showHeatmap,
    showFlowVectors,
    showZones,
    showBoundingBoxes,
    showIds,
    showTrails,
    privacyConfig,
    inputMode,
    renderBackgroundCanvas,
  ]);

  return (
    <div className="flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Top Monitor Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-slate-950/80 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <div className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500" />
          </div>
          <span className="text-xs font-mono font-semibold tracking-wider text-slate-200 uppercase">
            Live Stream Feed
          </span>
          <span className="text-xs text-slate-500">·</span>
          <span className="text-xs font-mono text-cyan-400">
            {tracks.length} ANONYMOUS TRACKS ACTIVE
          </span>
        </div>

        {/* Input Source Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-900/90 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => onInputModeChange('synthetic')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors font-medium ${
              inputMode === 'synthetic'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Synthetic crowd simulation with agent physics"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Synthetic Sim
          </button>

          <button
            onClick={() => onInputModeChange('webcam')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors font-medium ${
              inputMode === 'webcam'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Use live local webcam stream"
          >
            <Camera className="w-3.5 h-3.5" />
            Live Webcam
          </button>

          <button
            onClick={() => {
              onInputModeChange('video');
              fileInputRef.current?.click();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors font-medium ${
              inputMode === 'video'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Upload MP4/WebM video file"
          >
            <Video className="w-3.5 h-3.5" />
            Upload Video
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="video/mp4,video/webm,video/quicktime"
            className="hidden"
            onChange={onFileUpload}
          />
        </div>

        {/* HUD Quick Toggles */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowHeatmap(!showHeatmap)}
            className={`px-2.5 py-1 rounded text-xs font-mono transition-colors flex items-center gap-1.5 border ${
              showHeatmap
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
            title="Toggle Gaussian density concentration heatmap"
          >
            <Flame className="w-3.5 h-3.5" />
            Heatmap
          </button>

          <button
            onClick={() => setShowFlowVectors(!showFlowVectors)}
            className={`px-2.5 py-1 rounded text-xs font-mono transition-colors flex items-center gap-1.5 border ${
              showFlowVectors
                ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
            title="Toggle movement flow vectors"
          >
            <Navigation className="w-3.5 h-3.5" />
            Flow Arrows
          </button>

          <button
            onClick={() => setShowZones(!showZones)}
            className={`px-2.5 py-1 rounded text-xs font-mono transition-colors flex items-center gap-1.5 border ${
              showZones
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
            title="Toggle dynamic zone boundaries"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            Zones
          </button>

          <button
            onClick={onReset}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded border border-slate-700 transition-colors"
            title="Reset tracker & simulation state"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Viewport Container */}
      <div className="relative aspect-[16/10] w-full bg-black overflow-hidden flex items-center justify-center">
        {/* Render Canvas */}
        <canvas
          ref={canvasRef}
          width={800}
          height={500}
          className="w-full h-full object-contain"
        />

        {/* Fallback hidden videos for stream ingestion */}
        <video
          ref={webcamVideoRef}
          autoPlay
          playsInline
          muted
          className="hidden"
        />
        <video
          ref={uploadedVideoRef}
          autoPlay
          loop
          playsInline
          muted
          className="hidden"
        />

        {/* Robustness Warnings & Failure-Safe Banner */}
        {systemHealth.confidenceWarnings.length > 0 && (
          <div className="absolute top-3 left-3 right-3 flex flex-col gap-1 pointer-events-none">
            {systemHealth.confidenceWarnings.map((warn, idx) => (
              <div
                key={idx}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-950/90 border border-amber-500/40 text-amber-200 text-xs shadow-lg backdrop-blur-sm"
              >
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-semibold uppercase tracking-wider text-[11px]">
                  Robustness Alert:
                </span>
                <span>{warn}</span>
              </div>
            ))}
          </div>
        )}

        {/* Bottom Corner Privacy Shield Stamp */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1.5 px-2.5 py-1 bg-slate-950/85 border border-slate-800 rounded text-[11px] font-mono text-emerald-400 shadow-md">
          <Shield className="w-3.5 h-3.5" />
          <span>ZERO BIOMETRICS · TEMPORARY IDs ONLY</span>
        </div>

        {/* Bottom Left Stream Telemetry HUD */}
        <div className="absolute bottom-3 left-3 flex items-center gap-2 px-2.5 py-1 bg-slate-950/85 border border-slate-800 rounded text-[11px] font-mono text-slate-400 shadow-md">
          <span>FPS: <strong className="text-cyan-400">{systemHealth.fps}</strong></span>
          <span>·</span>
          <span>LATENCY: <strong className="text-cyan-400">{systemHealth.latencyMs}ms</strong></span>
          <span>·</span>
          <span>OVERLAP: <strong className={systemHealth.overlappingRatio > 0.25 ? 'text-amber-400' : 'text-slate-300'}>{Math.round(systemHealth.overlappingRatio * 100)}%</strong></span>
        </div>
      </div>

      {/* Scenario Bar (If synthetic mode active) */}
      {inputMode === 'synthetic' && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2 bg-slate-950/90 border-t border-slate-800">
          <span className="text-xs font-semibold text-slate-400 tracking-wide">
            Test Scenarios:
          </span>
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: 'normal_flow', label: '1. Normal Flow', desc: 'Fluid movement, baseline NORMAL' },
              { id: 'gradual_congestion', label: '2. Gradual Congestion', desc: 'Density steadily climbs' },
              { id: 'high_congestion', label: '3. High Congestion', desc: 'Bottleneck gridlock, HIGH-RISK' },
              { id: 'sudden_crowd_movement', label: '4. Sudden Turn', desc: 'Rapid direction reversal anomaly' },
              { id: 'overlapping_people', label: '5. Overlap & Occlusion', desc: 'Crossing trajectories' },
              { id: 'low_light', label: '6. Low-Light Noise', desc: 'Dim lighting & low confidence' },
            ].map((sc) => (
              <button
                key={sc.id}
                onClick={() => onScenarioChange(sc.id as ScenarioType)}
                className={`px-2.5 py-1 rounded text-xs transition-colors font-medium ${
                  currentScenario === sc.id
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                }`}
                title={sc.desc}
              >
                {sc.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
