import React from 'react';
import { ZoneMetrics } from '../types/crowd';
import {
  Users,
  Activity,
  Clock,
  ArrowDownRight,
  ArrowUpRight,
  Gauge,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface AnalyticsPanelProps {
  zoneMetrics: ZoneMetrics[];
  totalOccupants: number;
  historyDensity: number[];
  historyInflow: number[];
  historySpeed: number[];
}

export const AnalyticsPanel: React.FC<AnalyticsPanelProps> = ({
  zoneMetrics,
  totalOccupants,
  historyDensity,
  historyInflow,
  historySpeed,
}) => {
  // Aggregate system-wide metrics
  const avgDensity = Math.round(
    zoneMetrics.reduce((acc, z) => acc + z.density, 0) / Math.max(1, zoneMetrics.length)
  );
  const avgDwell = Number(
    (zoneMetrics.reduce((acc, z) => acc + z.avgDwellTime, 0) / Math.max(1, zoneMetrics.length)).toFixed(1)
  );
  const totalInflow = zoneMetrics.reduce((acc, z) => acc + z.entryRate, 0);
  const totalOutflow = zoneMetrics.reduce((acc, z) => acc + z.exitRate, 0);
  const avgSpeed = Number(
    (zoneMetrics.reduce((acc, z) => acc + z.avgSpeed, 0) / Math.max(1, zoneMetrics.length)).toFixed(1)
  );

  // SVG Sparkline Helper
  const renderSparkline = (data: number[], color: string, height: number = 36) => {
    if (data.length < 2) return null;
    const max = Math.max(...data, 1);
    const min = Math.min(...data, 0);
    const range = max - min || 1;
    const width = 140;

    const points = data
      .map((val, idx) => {
        const x = (idx / (data.length - 1)) * width;
        const y = height - ((val - min) / range) * (height - 8) - 4;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');

    return (
      <svg width={width} height={height} className="overflow-visible">
        <polyline
          fill="none"
          stroke={color}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={points}
        />
      </svg>
    );
  };

  return (
    <div className="flex flex-col gap-4">
      {/* 6 Key Macro Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total Occupants */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total People</span>
            <Users className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">{totalOccupants}</span>
            <span className="text-[11px] text-slate-400">active</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500">Live tracked anonymous</div>
        </div>

        {/* Current Density */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Avg Density</span>
            <Activity className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">{avgDensity}%</span>
            <span className="text-[11px] text-slate-400">of capacity</span>
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">Capacity load</span>
            {renderSparkline(historyDensity, '#f59e0b', 16)}
          </div>
        </div>

        {/* Avg Dwell Time */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Avg Dwell Time</span>
            <Clock className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">{avgDwell}s</span>
            <span className="text-[11px] text-slate-400">transit time</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500">Duration in zones</div>
        </div>

        {/* Inflow Rate */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Inflow</span>
            <ArrowDownRight className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">+{totalInflow}</span>
            <span className="text-[11px] text-slate-400">/min</span>
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">New arrivals</span>
            {renderSparkline(historyInflow, '#10b981', 16)}
          </div>
        </div>

        {/* Outflow Rate */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Outflow</span>
            <ArrowUpRight className="w-4 h-4 text-sky-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">-{totalOutflow}</span>
            <span className="text-[11px] text-slate-400">/min</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500">Successful egress</div>
        </div>

        {/* Avg Movement Speed */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Movement Speed</span>
            <Gauge className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">{avgSpeed}</span>
            <span className="text-[11px] text-slate-400">px/s</span>
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">Mean velocity</span>
            {renderSparkline(historySpeed, '#06b6d4', 16)}
          </div>
        </div>
      </div>

      {/* Dynamic Zone Breakdown Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="px-4 py-3 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
              Dynamic Zone Telemetry Matrix
            </h3>
          </div>
          <span className="text-xs text-slate-500">Continuous 1-second rolling window</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/40 text-slate-400 border-b border-slate-800/80 font-mono uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-4">Zone</th>
                <th className="py-2.5 px-3">Occupancy</th>
                <th className="py-2.5 px-3">Est. Density</th>
                <th className="py-2.5 px-3">In / Out Flow</th>
                <th className="py-2.5 px-3">Dwell Time</th>
                <th className="py-2.5 px-3">Velocity</th>
                <th className="py-2.5 px-3">Heading</th>
                <th className="py-2.5 px-3">Conflict</th>
                <th className="py-2.5 px-4">State</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {zoneMetrics?.filter((z) => z && z.zoneId).map((zone) => {
                const isHigh = zone.congestionRisk === 'HIGH-RISK CONGESTION';
                const isInc = zone.congestionRisk === 'INCREASING';

                return (
                  <tr key={zone.zoneId} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-200">
                      {zone.zoneName}
                    </td>
                    <td className="py-3 px-3 text-cyan-300 font-bold">
                      {zone.currentCount} <span className="text-slate-500 text-[10px] font-normal">pers</span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${
                              isHigh ? 'bg-rose-500' : isInc ? 'bg-amber-500' : 'bg-cyan-500'
                            }`}
                            style={{ width: `${Math.min(100, zone.density)}%` }}
                          />
                        </div>
                        <span className="text-slate-300">{zone.density}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-300">
                      +{zone.entryRate} / -{zone.exitRate}
                      <span className="text-slate-500 text-[10px]"> (Δ {zone.inflowOutflowBalance})</span>
                    </td>
                    <td className="py-3 px-3 text-slate-300">
                      {zone.avgDwellTime}s
                    </td>
                    <td className="py-3 px-3 text-slate-300">
                      {zone.avgSpeed} <span className="text-slate-500 text-[10px]">px/s</span>
                    </td>
                    <td className="py-3 px-3 text-sky-400">
                      {zone.dominantDirection.label}
                    </td>
                    <td className="py-3 px-3">
                      <span className={zone.flowConflictScore > 0.35 ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                        {zone.flowConflictScore}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[11px] font-semibold uppercase ${
                          isHigh
                            ? 'text-rose-400 font-bold'
                            : isInc
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {zone.congestionRisk}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
