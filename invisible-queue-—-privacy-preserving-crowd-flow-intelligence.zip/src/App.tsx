import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AnomalyEvent,
  AnonymousPersonTrack,
  CongestionAssessment,
  EnvironmentPreset,
  EventLogEntry,
  FlowVector,
  PrivacyConfig,
  RecommendationItem,
  ScenarioType,
  SimulationParameters,
  SystemHealthMetrics,
  ZoneDefinition,
  ZoneMetrics,
} from './types/crowd';
import { AnonymousTracker } from './vision/tracker';
import { VideoPersonDetector } from './vision/detector';
import { DEFAULT_ZONES, ZoneManager } from './analytics/zones';
import { FlowAnalyzer } from './analytics/flow';
import { CongestionEngine } from './analytics/congestion';
import { EarlyCongestionPredictor } from './prediction/timeSeries';
import { AnomalyDetector } from './anomaly/detector';
import { RecommendationEngine } from './ai/recommendation';
import { CrowdSimulationEngine } from './simulation/crowdSimulator';
import { ENVIRONMENT_PRESETS } from './config/presets';

// UI Components
import { Navbar } from './components/Navbar';
import { LiveMonitor } from './components/LiveMonitor';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { RiskPredictionPanel } from './components/RiskPredictionPanel';
import { AnomalyAndRecommendations } from './components/AnomalyAndRecommendations';
import { WhatIfSimulator } from './components/WhatIfSimulator';
import { PrivacyPanel } from './components/PrivacyPanel';
import { EvaluationPanel } from './components/EvaluationPanel';
import { EventLogPanel } from './components/EventLogPanel';
import { LinkedInPresentationModal } from './components/LinkedInPresentationModal';
import { DocumentationModal } from './components/DocumentationModal';

export default function App() {
  // Navigation & Modal States
  const [activeTab, setActiveTab] = useState<string>('monitor');
  const [isLinkedInModalOpen, setIsLinkedInModalOpen] = useState(false);
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState<EnvironmentPreset>(ENVIRONMENT_PRESETS[0]);

  // Input Source Mode
  const [inputMode, setInputMode] = useState<'synthetic' | 'webcam' | 'video'>('synthetic');
  const [currentScenario, setCurrentScenario] = useState<ScenarioType>('normal_flow');

  // Video Stream References
  const webcamVideoRef = useRef<HTMLVideoElement | null>(null);
  const uploadedVideoRef = useRef<HTMLVideoElement | null>(null);
  const webcamStreamRef = useRef<MediaStream | null>(null);

  // Engine Instances
  const trackerRef = useRef<AnonymousTracker>(new AnonymousTracker());
  const detectorRef = useRef<VideoPersonDetector>(new VideoPersonDetector());
  const zoneManagerRef = useRef<ZoneManager>(new ZoneManager(DEFAULT_ZONES));
  const congestionEngineRef = useRef<CongestionEngine>(new CongestionEngine());
  const predictorRef = useRef<EarlyCongestionPredictor>(new EarlyCongestionPredictor());
  const anomalyDetectorRef = useRef<AnomalyDetector>(new AnomalyDetector());
  const recommendationEngineRef = useRef<RecommendationEngine>(new RecommendationEngine());
  const simulatorRef = useRef<CrowdSimulationEngine>(new CrowdSimulationEngine(800, 500));

  // Core Data States
  const [tracks, setTracks] = useState<AnonymousPersonTrack[]>([]);
  const [zones, setZones] = useState<ZoneDefinition[]>(DEFAULT_ZONES);
  const [zoneMetrics, setZoneMetrics] = useState<ZoneMetrics[]>(() =>
    zoneManagerRef.current.computeMetrics([], Date.now())
  );
  const [flowVectors, setFlowVectors] = useState<FlowVector[]>([]);
  const [congestion, setCongestion] = useState<CongestionAssessment>({
    overallState: 'NORMAL',
    score: 18,
    dominantZoneId: 'zone-a',
    evidence: [],
    reasons: ['Crowd flow fluid', 'Density well within capacity thresholds'],
  });
  const [prediction, setPrediction] = useState(
    predictorRef.current.predict(zoneManagerRef.current.computeMetrics([], Date.now()), 18, false, 0)
  );
  const [anomalies, setAnomalies] = useState<AnomalyEvent[]>([]);
  const [recommendations, setRecommendations] = useState<RecommendationItem[]>(() =>
    recommendationEngineRef.current.evaluate(
      {
        overallState: 'NORMAL',
        score: 18,
        dominantZoneId: 'zone-a',
        evidence: [],
        reasons: ['Crowd flow fluid', 'Density well within capacity thresholds'],
      },
      zoneManagerRef.current.computeMetrics([], Date.now()),
      Date.now()
    )
  );
  const [eventLogs, setEventLogs] = useState<EventLogEntry[]>([]);

  // Simulation Parameters
  const [simParams, setSimParams] = useState<SimulationParameters>(
    simulatorRef.current.getParameters()
  );

  // System Health Metrics
  const [systemHealth, setSystemHealth] = useState<SystemHealthMetrics>({
    fps: 45,
    avgFps: 46,
    latencyMs: 14,
    luminanceLevel: 120,
    isLowLight: false,
    isCameraShaking: false,
    shakeMetric: 0,
    overlappingRatio: 0,
    overallConfidence: 88,
    confidenceWarnings: [],
  });

  // Privacy Configuration
  const [privacyConfig, setPrivacyConfig] = useState<PrivacyConfig>({
    blurLevel: 'none',
    hideRawVideo: false,
    anonymousBoundingBoxesOnly: true,
    zeroRawStorageVerified: true,
    showConfidenceMetrics: true,
    maskProtectedAreas: false,
  });

  // Rolling Telemetry for Sparkline Charts
  const [historyDensity, setHistoryDensity] = useState<number[]>([15, 18, 20, 22, 21, 24, 25, 23]);
  const [historyInflow, setHistoryInflow] = useState<number[]>([12, 14, 15, 16, 14, 15, 18, 17]);
  const [historySpeed, setHistorySpeed] = useState<number[]>([42, 44, 40, 41, 39, 43, 40, 42]);

  // Frame Timing Refs
  const lastFrameTimeRef = useRef<number>(performance.now());
  const frameCountRef = useRef<number>(0);
  const fpsAccumulatorRef = useRef<number>(0);
  const lastStateLogRef = useRef<string>('NORMAL');

  // Handle Preset Change
  const handlePresetChange = (preset: EnvironmentPreset) => {
    setSelectedPreset(preset);
    // Apply capacity adjustments to zone manager
    const currentZones = zoneManagerRef.current.getZones();
    currentZones.forEach((z) => {
      zoneManagerRef.current.setCapacity(z.id, preset.maxDensityCapacity);
    });
    setZones([...zoneManagerRef.current.getZones()]);
    addEventLog({
      zone: 'System',
      event: `Applied environment preset: ${preset.name}`,
      category: 'system',
      confidence: 100,
    });
  };

  // Logging Helper
  const addEventLog = (entry: Omit<EventLogEntry, 'id' | 'timestamp' | 'timeSec'>) => {
    const now = Date.now();
    const timeStr = new Date(now).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newLog: EventLogEntry = {
      id: `log-${now}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: timeStr,
      timeSec: Math.floor(now / 1000),
      ...entry,
    };
    setEventLogs((prev) => [newLog, ...prev.slice(0, 49)]);
  };

  // Notification banner state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Start Webcam
  const startWebcam = async () => {
    try {
      if (webcamStreamRef.current) {
        webcamStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      webcamStreamRef.current = stream;
      if (webcamVideoRef.current) {
        webcamVideoRef.current.srcObject = stream;
        webcamVideoRef.current.play();
      }
      setInputMode('webcam');
      addEventLog({
        zone: 'Feed',
        event: 'Live local webcam feed initialized',
        category: 'system',
        confidence: 95,
      });
    } catch (err: any) {
      const errMsg = `Webcam access unavailable (${err?.message || 'permission denied'}). Reverting to synthetic simulation.`;
      setToastMessage(errMsg);
      setTimeout(() => setToastMessage(null), 5000);
      addEventLog({
        zone: 'Feed',
        event: errMsg,
        category: 'system',
        confidence: 50,
      });
      setInputMode('synthetic');
    }
  };

  // Video Upload Handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // MIME Validation
    if (!file.type.startsWith('video/')) {
      const msg = 'Invalid format. Please upload a standard video file (.mp4, .webm).';
      setToastMessage(msg);
      setTimeout(() => setToastMessage(null), 5000);
      addEventLog({
        zone: 'Feed',
        event: 'File upload rejected: non-video format',
        category: 'system',
        confidence: 0,
      });
      return;
    }

    // Size limit (50 MB)
    if (file.size > 50 * 1024 * 1024) {
      const msg = 'File exceeds 50MB limit. Please provide a lighter test video.';
      setToastMessage(msg);
      setTimeout(() => setToastMessage(null), 5000);
      addEventLog({
        zone: 'Feed',
        event: 'File upload rejected: exceeds 50MB ceiling',
        category: 'system',
        confidence: 0,
      });
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    if (uploadedVideoRef.current) {
      uploadedVideoRef.current.src = objectUrl;
      uploadedVideoRef.current.play();
    }
    setInputMode('video');
    addEventLog({
      zone: 'Feed',
      event: `Uploaded video feed loaded: "${file.name}" (${(file.size / (1024 * 1024)).toFixed(1)}MB)`,
      category: 'system',
      confidence: 90,
    });
  };

  // Switch Input Source
  const handleInputModeChange = (mode: 'synthetic' | 'webcam' | 'video') => {
    if (mode === 'webcam') {
      startWebcam();
    } else {
      if (webcamStreamRef.current) {
        webcamStreamRef.current.getTracks().forEach((t) => t.stop());
        webcamStreamRef.current = null;
      }
      setInputMode(mode);
    }
  };

  // Scenario Change Handler
  const handleScenarioChange = (scenario: ScenarioType) => {
    setCurrentScenario(scenario);
    simulatorRef.current.loadScenario(scenario);
    trackerRef.current.reset();
    detectorRef.current.reset();
    setSimParams(simulatorRef.current.getParameters());

    const scenarioNames: { [k in ScenarioType]: string } = {
      normal_flow: '1. Normal Flow',
      gradual_congestion: '2. Gradual Congestion',
      high_congestion: '3. High Congestion',
      sudden_crowd_movement: '4. Sudden Turn Anomaly',
      overlapping_people: '5. Overlap & Occlusions',
      low_light: '6. Low-Light Noise',
    };

    addEventLog({
      zone: 'Scenario',
      event: `Activated benchmark scenario: ${scenarioNames[scenario]}`,
      category: 'simulation',
      confidence: 100,
    });
  };

  // Reset System State
  const handleReset = () => {
    trackerRef.current.reset();
    detectorRef.current.reset();
    simulatorRef.current.loadScenario(currentScenario);
    setTracks([]);
    addEventLog({
      zone: 'System',
      event: 'Tracker, detector & simulation memory cleared',
      category: 'privacy',
      confidence: 100,
    });
  };

  // START DEMO Primary Button Action
  const handleStartDemo = () => {
    setInputMode('synthetic');
    handleScenarioChange('gradual_congestion');
    setActiveTab('monitor');
    addEventLog({
      zone: 'System',
      event: 'Started automated end-to-end crowd intelligence demonstration',
      category: 'simulation',
      confidence: 100,
      recommendation: 'Observe density buildup, time-series prediction, and operational suggestions.',
    });
  };

  // Update What-If Simulation Parameters
  const handleUpdateSimParams = (newParams: Partial<SimulationParameters>) => {
    simulatorRef.current.updateParameters(newParams);
    setSimParams(simulatorRef.current.getParameters());

    if (newParams.entranceClosed !== undefined) {
      zoneManagerRef.current.toggleEntranceClosed('zone-a', newParams.entranceClosed);
      addEventLog({
        zone: 'Zone A',
        event: newParams.entranceClosed ? 'Main entrance closed (What-If)' : 'Main entrance reopened',
        category: 'simulation',
        confidence: 100,
      });
    }

    if (newParams.alternatePathOpen !== undefined) {
      zoneManagerRef.current.toggleAlternateOpen('zone-d', newParams.alternatePathOpen);
      addEventLog({
        zone: 'Zone D',
        event: newParams.alternatePathOpen ? 'Alternate bypass corridor opened' : 'Alternate bypass closed',
        category: 'simulation',
        confidence: 100,
      });
    }

    if (newParams.zoneBRestricted !== undefined) {
      zoneManagerRef.current.toggleZoneRestricted('zone-b', newParams.zoneBRestricted);
      addEventLog({
        zone: 'Zone B',
        event: newParams.zoneBRestricted ? 'Zone B concourse restricted' : 'Zone B access restored',
        category: 'simulation',
        confidence: 100,
      });
    }
  };

  // Main Real-Time Processing Loop
  useEffect(() => {
    let animId: number;

    const processTick = () => {
      const now = performance.now();
      const deltaSec = (now - lastFrameTimeRef.current) / 1000;
      lastFrameTimeRef.current = now;
      const curTime = Date.now();

      // FPS Calculation
      frameCountRef.current++;
      fpsAccumulatorRef.current += deltaSec;
      let curFps = systemHealth.fps;
      let avgFps = systemHealth.avgFps;
      if (fpsAccumulatorRef.current >= 0.5) {
        curFps = Math.round(frameCountRef.current / fpsAccumulatorRef.current);
        avgFps = Math.round((systemHealth.avgFps * 0.7) + (curFps * 0.3));
        frameCountRef.current = 0;
        fpsAccumulatorRef.current = 0;
      }

      const procStartTime = performance.now();

      let rawDetections: any[] = [];
      let isLowLight = false;
      let isCameraShaking = false;
      let luminanceLevel = 128;

      if (inputMode === 'synthetic') {
        // Update synthetic agent physics
        simulatorRef.current.update(deltaSec);
        const simDet = simulatorRef.current.getDetections();
        rawDetections = simDet.detections;
        isLowLight = simDet.isLowLight;
        isCameraShaking = simDet.isCameraShaking;
        luminanceLevel = isLowLight ? 28 : 120;
      } else if (inputMode === 'webcam' && webcamVideoRef.current && webcamVideoRef.current.readyState >= 2) {
        const res = detectorRef.current.analyzeFrame(webcamVideoRef.current, 800 / 320, 500 / 240);
        rawDetections = res.detections;
        isLowLight = res.isLowLight;
        isCameraShaking = res.isCameraShaking;
        luminanceLevel = res.averageLuminance;
      } else if (inputMode === 'video' && uploadedVideoRef.current && uploadedVideoRef.current.readyState >= 2) {
        const res = detectorRef.current.analyzeFrame(uploadedVideoRef.current, 800 / 320, 500 / 240);
        rawDetections = res.detections;
        isLowLight = res.isLowLight;
        isCameraShaking = res.isCameraShaking;
        luminanceLevel = res.averageLuminance;
      }

      // 1. Anonymous Multi-Person Tracking
      const activeTracks = trackerRef.current.update(rawDetections, curTime, deltaSec);

      // 2. Dynamic Zone Containment & Telemetry
      zoneManagerRef.current.assignTracksToZones(activeTracks, 800, 500, curTime);
      const computedZoneMetrics = zoneManagerRef.current.computeMetrics(activeTracks, curTime);

      // 3. Flow Vector Analysis
      const vectors = FlowAnalyzer.extractFlowVectors(activeTracks);
      const globalConflictIndex = FlowAnalyzer.computeGlobalConflictIndex(activeTracks);

      // 4. Multi-Signal Congestion Evaluation (Density alone not used)
      const congestionAssessment = congestionEngineRef.current.evaluate(computedZoneMetrics, globalConflictIndex);

      // 5. Early Congestion Time-Series Prediction (Every ~1 second)
      if (Math.random() < 0.2) {
        predictorRef.current.addSnapshot(activeTracks.length, computedZoneMetrics, curTime);
      }

      // Check overlap ratio
      const overlappingTracks = activeTracks.filter((t) => t.isOverlapping);
      const overlappingRatio = activeTracks.length > 0 ? overlappingTracks.length / activeTracks.length : 0;

      const predictionOutcome = predictorRef.current.predict(
        computedZoneMetrics,
        congestionAssessment.score,
        isLowLight || isCameraShaking,
        overlappingRatio
      );

      // 6. Anomaly Detection
      const detectedAnomaly = anomalyDetectorRef.current.evaluate(computedZoneMetrics, activeTracks, curTime);
      if (detectedAnomaly) {
        setAnomalies(anomalyDetectorRef.current.getRecentEvents());
        addEventLog({
          zone: detectedAnomaly.zoneName,
          event: detectedAnomaly.description,
          category: 'anomaly',
          confidence: detectedAnomaly.confidence,
        });
      }

      // 7. Operational AI Recommendations
      const updatedRecs = recommendationEngineRef.current.evaluate(
        congestionAssessment,
        computedZoneMetrics,
        curTime
      );

      // Log State Transition if risk status changed
      if (congestionAssessment.overallState !== lastStateLogRef.current) {
        lastStateLogRef.current = congestionAssessment.overallState;
        addEventLog({
          zone: congestionAssessment.dominantZoneId.toUpperCase(),
          event: `Congestion transition: ${congestionAssessment.overallState}`,
          category: 'congestion',
          confidence: Math.round(predictionOutcome.confidence),
          recommendation: updatedRecs[0]?.actionText,
        });
      }

      // Robustness Warnings
      const warnings: string[] = [];
      if (isLowLight) {
        warnings.push('LOW LIGHT DETECTED: Luminance below threshold. Optical confidence degraded.');
      }
      if (isCameraShaking) {
        warnings.push('CAMERA SHAKE DETECTED: Global drift elevated. Motion vector stabilization active.');
      }
      if (overlappingRatio > 0.3) {
        warnings.push('OVERLAPPING OCCLUSIONS: Multiple intersecting tracks. Track persistence active.');
      }

      const procLatency = Math.round(performance.now() - procStartTime);

      // Update States
      setTracks(activeTracks);
      setZoneMetrics(computedZoneMetrics);
      setFlowVectors(vectors);
      setCongestion(congestionAssessment);
      setPrediction(predictionOutcome);
      setRecommendations(updatedRecs);

      setSystemHealth({
        fps: curFps,
        avgFps,
        latencyMs: procLatency,
        luminanceLevel,
        isLowLight,
        isCameraShaking,
        shakeMetric: isCameraShaking ? 65 : 12,
        overlappingRatio,
        overallConfidence: Math.round(predictionOutcome.confidence),
        confidenceWarnings: warnings,
      });

      // Update Rolling Sparklines
      if (Math.random() < 0.1) {
        const meanDensity = Math.round(
          computedZoneMetrics.reduce((a, b) => a + b.density, 0) / Math.max(1, computedZoneMetrics.length)
        );
        const meanInflow = computedZoneMetrics.reduce((a, b) => a + b.entryRate, 0);
        const meanSpeed = Math.round(
          computedZoneMetrics.reduce((a, b) => a + b.avgSpeed, 0) / Math.max(1, computedZoneMetrics.length)
        );

        setHistoryDensity((prev) => [...prev.slice(1), meanDensity]);
        setHistoryInflow((prev) => [...prev.slice(1), meanInflow]);
        setHistorySpeed((prev) => [...prev.slice(1), meanSpeed]);
      }

      animId = requestAnimationFrame(processTick);
    };

    animId = requestAnimationFrame(processTick);
    return () => cancelAnimationFrame(animId);
  }, [inputMode, currentScenario]);

  // Background Canvas Render Callback for LiveMonitor
  const handleRenderBackground = useCallback(
    (ctx: CanvasRenderingContext2D, privacyBlur: boolean) => {
      simulatorRef.current.renderScene(ctx, privacyBlur);
    },
    []
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        selectedPreset={selectedPreset}
        onPresetChange={handlePresetChange}
        onStartDemo={handleStartDemo}
        onOpenLinkedInModal={() => setIsLinkedInModalOpen(true)}
        onOpenDocModal={() => setIsDocModalOpen(true)}
      />

      {/* Non-blocking Notification Toast */}
      {toastMessage && (
        <div className="max-w-7xl mx-auto px-4 pt-3">
          <div className="flex items-center justify-between p-3 rounded-lg bg-amber-950/80 border border-amber-500/40 text-amber-200 text-xs shadow-lg">
            <span>{toastMessage}</span>
            <button
              onClick={() => setToastMessage(null)}
              className="text-amber-400 hover:text-amber-200 font-bold ml-3"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Content Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        {/* Tab View Routing */}
        {activeTab === 'monitor' && (
          <div className="space-y-6">
            <LiveMonitor
              tracks={tracks}
              zones={zones}
              zoneMetrics={zoneMetrics}
              flowVectors={flowVectors}
              systemHealth={systemHealth}
              privacyConfig={privacyConfig}
              currentScenario={currentScenario}
              inputMode={inputMode}
              onScenarioChange={handleScenarioChange}
              onInputModeChange={handleInputModeChange}
              onPrivacyToggle={(key, val) => setPrivacyConfig((prev) => ({ ...prev, [key]: val }))}
              onReset={handleReset}
              renderBackgroundCanvas={handleRenderBackground}
              webcamVideoRef={webcamVideoRef}
              uploadedVideoRef={uploadedVideoRef}
              onFileUpload={handleFileUpload}
            />

            {/* Quick Macro Analytics Row below feed */}
            <AnalyticsPanel
              zoneMetrics={zoneMetrics}
              totalOccupants={tracks.length}
              historyDensity={historyDensity}
              historyInflow={historyInflow}
              historySpeed={historySpeed}
            />

            {/* Quick Risk Preview */}
            <RiskPredictionPanel congestion={congestion} prediction={prediction} />
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <AnalyticsPanel
              zoneMetrics={zoneMetrics}
              totalOccupants={tracks.length}
              historyDensity={historyDensity}
              historyInflow={historyInflow}
              historySpeed={historySpeed}
            />
            <RiskPredictionPanel congestion={congestion} prediction={prediction} />
          </div>
        )}

        {activeTab === 'risk' && (
          <div className="space-y-6">
            <RiskPredictionPanel congestion={congestion} prediction={prediction} />
            <AnomalyAndRecommendations anomalies={anomalies} recommendations={recommendations} />
          </div>
        )}

        {activeTab === 'anomalies' && (
          <div className="space-y-6">
            <AnomalyAndRecommendations anomalies={anomalies} recommendations={recommendations} />
          </div>
        )}

        {activeTab === 'simulator' && (
          <div className="space-y-6">
            <WhatIfSimulator
              params={simParams}
              onUpdateParams={handleUpdateSimParams}
              zoneMetrics={zoneMetrics}
              onResetParams={() => {
                simulatorRef.current.loadScenario('normal_flow');
                setSimParams(simulatorRef.current.getParameters());
              }}
            />
          </div>
        )}

        {activeTab === 'privacy' && (
          <div className="space-y-6">
            <PrivacyPanel
              config={privacyConfig}
              onUpdateConfig={(newCfg) => setPrivacyConfig((prev) => ({ ...prev, ...newCfg }))}
              onPurgeTemporaryTracks={handleReset}
              activeTrackCount={tracks.length}
            />
          </div>
        )}

        {activeTab === 'evaluation' && (
          <div className="space-y-6">
            <EvaluationPanel systemHealth={systemHealth} />
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="space-y-6">
            <EventLogPanel logs={eventLogs} onClearLogs={() => setEventLogs([])} />
          </div>
        )}
      </main>

      {/* Footer Status Bar */}
      <footer className="bg-slate-950 border-t border-slate-900 py-3 px-6 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>System Healthy: Multi-person anonymous tracking active</span>
          <span>·</span>
          <span>Camera: {inputMode.toUpperCase()}</span>
          <span>·</span>
          <span>Preset: {selectedPreset.name}</span>
        </div>
        <div className="flex items-center gap-3 font-mono text-[11px]">
          <span>PII: NONE</span>
          <span>·</span>
          <span>STORAGE: VOLATILE RAM ONLY</span>
          <span>·</span>
          <span className="text-cyan-400">INVISIBLE QUEUE v1.0.0</span>
        </div>
      </footer>

      {/* LinkedIn Presentation Modal */}
      <LinkedInPresentationModal
        isOpen={isLinkedInModalOpen}
        onClose={() => setIsLinkedInModalOpen(false)}
        onSelectScenario={handleScenarioChange}
        onSwitchTab={setActiveTab}
      />

      {/* Documentation Modal */}
      <DocumentationModal
        isOpen={isDocModalOpen}
        onClose={() => setIsDocModalOpen(false)}
      />
    </div>
  );
}
