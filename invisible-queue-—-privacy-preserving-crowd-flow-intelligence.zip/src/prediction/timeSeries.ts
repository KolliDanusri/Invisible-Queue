import { PredictionLevel, PredictionResult, ZoneMetrics } from '../types/crowd';

export interface TimeSeriesDataPoint {
  timestamp: number;
  totalCount: number;
  maxZoneDensity: number;
  avgVelocity: number;
  inflowSum: number;
  outflowSum: number;
}

export class EarlyCongestionPredictor {
  private history: TimeSeriesDataPoint[] = [];
  private maxHistoryLength: number = 30; // ~30 snapshots (every 1s)

  public addSnapshot(
    totalCount: number,
    zones: ZoneMetrics[],
    currentTime: number
  ): void {
    const maxDensity = zones.reduce((max, z) => Math.max(max, z.density), 0);
    const avgVelocity = zones.reduce((acc, z) => acc + z.avgSpeed, 0) / Math.max(1, zones.length);
    const inflowSum = zones.reduce((acc, z) => acc + z.entryRate, 0);
    const outflowSum = zones.reduce((acc, z) => acc + z.exitRate, 0);

    this.history.push({
      timestamp: currentTime,
      totalCount,
      maxZoneDensity: maxDensity,
      avgVelocity,
      inflowSum,
      outflowSum,
    });

    if (this.history.length > this.maxHistoryLength) {
      this.history.shift();
    }
  }

  public predict(
    currentZones: ZoneMetrics[],
    currentCongestionScore: number,
    isLowLightOrShake: boolean,
    overlappingRatio: number
  ): PredictionResult {
    const timeHorizonSec = 90; // 90 seconds forward lookahead
    const n = this.history.length;

    // Handle early initialization or insufficient data
    if (n < 6) {
      return {
        level: 'NORMAL',
        confidence: 42,
        timeHorizonSec,
        projectedCountInHorizon: currentZones.reduce((a, b) => a + b.currentCount, 0),
        isLowConfidence: true,
        lowConfidenceReason: 'Insufficient historical time-series data (< 6s window). Accumulating baseline...',
        trendVelocity: 0,
        contributingFactors: ['Initializing buffer window', 'Gathering directional telemetry'],
      };
    }

    // 1. Calculate linear slope of maxZoneDensity over recent window
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumXX = 0;

    for (let i = 0; i < n; i++) {
      const x = i; // step
      const y = this.history[i].maxZoneDensity;
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumXX += x * x;
    }

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX + 1e-6);
    // slope is density change per second
    const trendVelocity = Number((slope * 60).toFixed(1)); // % change per minute

    // Calculate velocity slope (are people slowing down?)
    const firstHalfVel = this.history.slice(0, Math.floor(n / 2)).reduce((a, b) => a + b.avgVelocity, 0) / Math.max(1, Math.floor(n / 2));
    const recentHalfVel = this.history.slice(Math.floor(n / 2)).reduce((a, b) => a + b.avgVelocity, 0) / Math.max(1, Math.ceil(n / 2));
    const isDecelerating = recentHalfVel < firstHalfVel * 0.82;

    const latest = this.history[n - 1];
    const netFlowDelta = latest.inflowSum - latest.outflowSum;

    // Projected future density in 90 seconds
    const projectedDensity = Math.max(0, latest.maxZoneDensity + (slope * timeHorizonSec));
    const projectedCount = Math.round(
      latest.totalCount + (netFlowDelta * (timeHorizonSec / 60))
    );

    // Factors influencing prediction
    const factors: string[] = [];
    if (trendVelocity > 10) factors.push(`Rapid density expansion trend (+${trendVelocity}%/min)`);
    else if (trendVelocity < -10) factors.push(`Clearing trend (-${Math.abs(trendVelocity)}%/min)`);
    else factors.push('Steady density equilibrium');

    if (isDecelerating) factors.push(`Systemic velocity decay (moving ${recentHalfVel.toFixed(1)} px/s vs previous ${firstHalfVel.toFixed(1)} px/s)`);
    if (netFlowDelta > 5) factors.push(`Positive inflow accumulation (+${netFlowDelta} net/min)`);

    // Determine predicted level
    let level: PredictionLevel = 'NORMAL';
    if (projectedDensity >= 85 || (currentCongestionScore >= 55 && trendVelocity >= 0)) {
      level = 'HIGH-RISK';
    } else if (projectedDensity >= 60 || trendVelocity >= 12 || (isDecelerating && latest.maxZoneDensity > 45)) {
      level = 'INCREASING';
    }

    // Confidence calibration
    let confidence = 82;
    let isLowConfidence = false;
    let lowConfidenceReason = '';

    // Penalty for environmental drawbacks (low light, camera shake, occlusion overlap)
    if (isLowLightOrShake) {
      confidence -= 32;
      isLowConfidence = true;
      lowConfidenceReason = 'Low environmental fidelity / camera jitter detected.';
    }

    if (overlappingRatio > 0.35) {
      confidence -= 22;
      isLowConfidence = true;
      lowConfidenceReason = (lowConfidenceReason ? lowConfidenceReason + ' ' : '') + 'High crowd occlusion overlap (> 35%).';
    }

    if (Math.abs(trendVelocity) > 40) {
      // Extremely erratic changes reduce model certainty
      confidence -= 15;
    }

    confidence = Math.max(28, Math.min(94, Math.round(confidence)));
    if (confidence < 55) {
      isLowConfidence = true;
      if (!lowConfidenceReason) {
        lowConfidenceReason = 'Prediction confidence is low due to dynamic variance.';
      }
    }

    return {
      level,
      confidence,
      timeHorizonSec,
      projectedCountInHorizon: Math.max(0, projectedCount),
      isLowConfidence,
      lowConfidenceReason,
      trendVelocity,
      contributingFactors: factors,
    };
  }

  public getRecentHistory(): TimeSeriesDataPoint[] {
    return [...this.history];
  }
}
