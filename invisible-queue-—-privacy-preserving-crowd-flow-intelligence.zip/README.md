# INVISIBLE QUEUE — Privacy-Preserving Crowd Flow Intelligence

[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)
[![Privacy](https://img.shields.io/badge/GDPR%2FCCPA-Non--PII%20Verified-emerald.svg)]()
[![Platform](https://img.shields.io/badge/runtime-React%20%7C%20FastAPI%20%7C%20OpenCV-cyan.svg)]()

> A production-quality, real-time AI computer vision system that analyzes crowd movement from video or camera feeds to detect, understand, and predict congestion **without identifying people**.

---

## 🎯 1. Project Goal & Core Philosophy

Traditional video surveillance systems rely on facial recognition and biometric identity extraction—creating severe ethical dilemmas, cybersecurity targets, and compliance violations under GDPR and CCPA.

**INVISIBLE QUEUE** shifts the paradigm from **Identity Tracking** to **Flow Dynamics**:
- **DETECT → TRACK → UNDERSTAND → PREDICT → ALERT → RECOMMEND**
- **Strict Anti-Surveillance Guardrails**:
  - ❌ No face recognition
  - ❌ No identity recognition
  - ❌ No permanent person IDs
  - ❌ No biometric embeddings
  - ❌ No raw video storage by default
  - ✅ Ephemeral anonymous IDs (`Person-01`, `Person-02`) that are automatically purged when an individual exits the scene.

---

## ⚙️ 2. Core Architecture Pipeline

```
Camera / Video Stream / Synthetic Agents
                  ↓
       Person Detection (CV Motion Blobs / YOLO)
                  ↓
       Anonymous Multi-Person Tracking (ByteTrack / IoU)
                  ↓
       Dynamic Zone Analysis (Ray-Casting Polygons)
                  ↓
       Density + Movement Flow Analysis (Vector Field & Conflicts)
                  ↓
       Multi-Signal Congestion Engine (Density + Speed + Conflict + Net Inflow)
                  ↓
       Early Congestion Prediction (90s Time-Series Lookahead)
                  ↓
       Anomaly Detection ("Unusual Movement Pattern Detected")
                  ↓
       Operational AI Recommendations ("AI-generated suggestions")
                  ↓
       Operator Dashboard + Interactive What-If Simulator
```

---

## 🚀 3. Quick Start & Execution Instructions

### A. Web Client (One-Command Startup)
```bash
# Clone the repository
git clone https://github.com/example/invisible-queue.git
cd invisible-queue

# Install NPM dependencies
npm install

# Start local development server
npm run dev
# Open http://localhost:3000 in your browser
```

### B. Optional Standalone Python Backend
```bash
# Install Python dependencies
pip install -r requirements.txt

# Run the FastAPI vision server
uvicorn backend.app:app --host 0.0.0.0 --port 8000 --reload
```

---

## 🧪 4. Running the Demos & Test Scenarios

Once the application is running, click **"START DEMO"** in the top navigation bar to launch an automated demonstration.

You can switch between 3 video input modes:
1. **Synthetic Crowd Simulator**: Fully interactive 2D agent-based physics model simulating bottlenecks, turnstiles, and bypass corridors.
2. **Live Webcam**: Real-time processing of your local webcam feed using client-side canvas computer vision.
3. **Prerecorded Video**: Upload any `.mp4` or `.webm` file (<50MB) for automated zone analysis.

### Included Test Scenarios:
- **Scenario 1 (Normal Flow)**: Standard pedestrian transit. State: `NORMAL`.
- **Scenario 2 (Gradual Congestion)**: Influx rate exceeds egress capacity. State: `INCREASING`.
- **Scenario 3 (High Congestion)**: Chokepoint saturation and velocity decay. State: `HIGH-RISK CONGESTION`.
- **Scenario 4 (Sudden Crowd Movement)**: Rapid collective reversal or acceleration. Flags: `"Unusual movement pattern detected"`.
- **Scenario 5 (Overlapping People)**: High-density crisscross paths. System flags occlusion overlap and maintains track persistence.
- **Scenario 6 (Low Light Noise)**: Reduced sensor luminance. System triggers failure-safe: `"LOW CONFIDENCE: Improve lighting or reposition camera"`.

---

## 🔬 5. Multi-Signal Congestion Detection

Unlike naive systems that trigger alarms based solely on spatial density, **Invisible Queue** fuses 5 orthogonal signals:
1. **Density Occupancy Percentage** ($N / \text{Capacity}$)
2. **Mean Movement Velocity** (deceleration toward standstill)
3. **Flow Conflict Index** (cosine dot-product of opposing movement vectors $\vec{v}_1 \cdot \vec{v}_2 < -0.3$)
4. **Inflow / Outflow Balance** (net accumulation delta $\Delta = \text{In} - \text{Out}$)
5. **Mean Dwell Time** (duration of stagnation inside critical zones)

---

## 🧪 6. Automated Testing

Run the automated in-app unit tests directly in the **Evaluation Panel** or via CLI:
```bash
npm run lint
```
The test suite validates:
- Anonymous Person Counting & Token Formatting (`Person-XX`)
- Bounding box IoU bipartite matching
- Ray-casting polygon containment
- Inflow/outflow accumulation math
- Multi-signal congestion engine state transitions
- Confidence degradation under environmental noise
- 90-second forward time-series trend extrapolation
- Anomaly detector trigger thresholds

---

## ⚠️ 7. Limitations & Honest Engineering Disclosures

1. **Occlusion & Severe Overlap**: Extremely dense crowds can cause bounding boxes to merge into single contours. The system uses a 30-frame track memory and reduces confidence rather than hallucinating precision.
2. **Low-Light Environments**: Optical SNR decreases in dim concourses; our failure-safe monitors average luminance and warns operators when confidence drops below safe operating thresholds.
3. **Perspective Distortion**: Monocular cameras without ground-plane calibration experience depth distortion; we recommend configuring environment presets (Station, Mall, Campus, Stadium).
4. **Predictions Are Not Guarantees**: All forecasts are mathematical extrapolations of rolling velocity vectors and are prominently labeled: *"SIMULATION — NOT A GUARANTEED REAL-WORLD PREDICTION"*.

---

## 📄 8. License
Apache License 2.0. Built with privacy-by-design principles for public safety.
