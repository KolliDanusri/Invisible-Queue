import express from 'express';
import type { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// In AI Studio / Cloud Run container, Nginx reverse proxy binds to 8080 and forwards to 3000.
// Port 3000 is the required application listener port.
const PORT = process.env.PORT && process.env.PORT !== '8080'
  ? parseInt(process.env.PORT, 10)
  : 3000;

// Health check endpoint for Cloud Run and monitoring
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    system: 'Invisible Queue',
    privacy: 'zero_biometrics',
    uptime: process.uptime(),
  });
});

// Serve compiled static assets from dist
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

// Fallback to index.html for client-side routing
app.get('*', (_req: Request, res: Response) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Production server running on http://0.0.0.0:${PORT}`);
});
